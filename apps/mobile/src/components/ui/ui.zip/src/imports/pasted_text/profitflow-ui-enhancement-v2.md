# ProfitFlow UI Enhancement Prompt (Version 2)

You are continuing an existing Figma project for **ProfitFlow**, a premium cryptocurrency trading intelligence platform.

**IMPORTANT:**
Do NOT redesign the existing screens.
Do NOT change the current visual style.
Do NOT modify the existing design system.

Instead, **extend the current design** by adding all missing screens, user flows, reusable components, states, and interactions while maintaining complete visual consistency.

The current design already has:

* Premium dark fintech style
* Modern cards
* Beautiful dashboard
* Rounded corners
* Glassmorphism
* Excellent typography
* Consistent spacing
* Bottom navigation

Maintain this exact design language.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Goal

Transform the current UI into a **complete production-ready mobile application**.

Think like a Senior Product Designer at Apple, Stripe, Linear, or Revolut.

The final design should be developer-ready.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Preserve Existing Style

Do NOT change:

• Color palette
• Typography
• Card style
• Navigation
• Icon style
• Button style
• Spacing
• Glass effects
• Shadows
• Corner radius

Everything new should look like it was designed on the same day by the same design team.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Add Missing User Flows

## 1. Authentication Flow

Design complete flow:

Splash Screen

↓

Welcome Screen

↓

Login

↓

Create Account

↓

Forgot Password

↓

Email Verification

↓

Success Screen

↓

Exchange Setup

↓

Dashboard

Include:

• Social login
• Email login
• Biometric login placeholder
• Password visibility
• Validation errors
• Success animations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 2. Exchange Connection Flow

Create complete onboarding for connecting exchanges.

Supported exchanges:

• Binance

• CoinDCX

Future Ready:

• Bybit

• OKX

• KuCoin

• Kraken

Flow:

Exchange List

↓

Select Exchange

↓

Paste API Key

↓

Paste Secret

↓

Permission Guide

↓

Connection Test

↓

Success

↓

Dashboard

Design:

• Permission explanation
• API key instructions
• Validation states
• Loading state
• Error state
• Connected state
• Disconnected state

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 3. Opportunity Details Screen

Design a premium detail screen.

Include:

Large hero card

Symbol

Buy Exchange

Sell Exchange

Buy Price

Sell Price

Spread %

Estimated Profit

Trading Fee

Network Fee

Liquidity

Risk Score

Confidence Score

Time Detected

Historical Performance

Opportunity Timeline

Market Depth

Paper Trade Button

Favorite Button

Share Button

Everything should feel premium.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 4. Scanner Filters

Design filter experience.

Include:

Exchange

Symbol

Minimum Profit

Minimum Confidence

Liquidity

Risk

Spread %

Market

Sort Options

Reset

Apply

Use beautiful bottom sheets.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 5. Paper Trading

Design complete module.

Screens:

Paper Trading Dashboard

Open Positions

Closed Positions

Trade Details

Trade History

Statistics

Performance

ROI

Win Rate

Equity Curve

Virtual Wallet

Beautiful cards.

Minimal design.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 6. Portfolio

Expand portfolio.

Add:

Asset Details

Exchange Balances

Allocation

Performance

Transaction History

Performance Charts

Deposit History

Withdrawal History

Empty Portfolio

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 7. Analytics

Design premium analytics.

Include:

Daily

Weekly

Monthly

Scanner Performance

Opportunity Performance

Exchange Comparison

Profit Trend

Win Rate

Top Coins

Most Profitable Exchange

Use elegant charts.

Do NOT overload the screen.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 8. Notification Center

Design inbox.

Types:

Opportunity

Scanner

Exchange

Security

System

Allow:

Filter

Mark Read

Delete

Notification Detail

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 9. Settings

Expand settings.

Sections:

Account

Appearance

Theme

Language

Scanner Rules

Notifications

API Keys

Exchange Management

Privacy

Security

Biometric

About

Version

Licenses

Support

FAQ

Contact

Logout

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 10. Profile

Create profile.

Include:

Avatar

Name

Email

Subscription

Connected Exchanges

Scanner Status

Security Status

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Missing States

Create every state.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Loading

Dashboard Skeleton

Scanner Skeleton

Portfolio Skeleton

Cards

Charts

Lists

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Empty States

No Opportunities

No Portfolio

No Notifications

No Exchanges

No Paper Trades

No Analytics

Beautiful illustrations.

Friendly messages.

Primary CTA.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Error States

Internet Lost

Exchange Offline

API Error

Permission Error

Authentication Error

Maintenance

Rate Limit

Use friendly messaging.

Never expose technical errors.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Offline Mode

Create offline experience.

Show cached data.

Display reconnect status.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Success Screens

Exchange Connected

Paper Trade Executed

Settings Saved

Password Changed

Profile Updated

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Search Experience

Global Search

Search:

Coins

Opportunities

Portfolio

Notifications

Settings

Recent Searches

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Component Library

Create reusable components.

Buttons

Cards

Stat Cards

Opportunity Cards

Portfolio Cards

Exchange Cards

Chips

Badges

Progress

Charts

Dialogs

Bottom Sheets

Inputs

Dropdowns

Search Bars

Segment Controls

Tabs

Timeline

Risk Indicator

Confidence Indicator

Profit Badge

Scanner Status Badge

Portfolio Summary Card

Section Headers

Shimmer Loaders

Empty State Components

Error Components

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# User Flows

Create complete prototypes for:

Authentication

Exchange Connection

Dashboard

Scanner

Opportunity Details

Paper Trading

Portfolio

Notifications

Settings

Logout

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Prototype

Link every screen.

Every button should navigate correctly.

Every bottom sheet should open.

Every dialog should be interactive.

Create smooth transitions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Design System

Expand the design system.

Include:

Typography

Spacing

Grid

Elevation

Colors

Icons

Illustrations

Charts

Motion

Tokens

Component Variants

Interaction States

Accessibility

Developer Notes

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Deliverables

Do NOT redesign existing screens.

Keep the current visual identity.

Only extend the project.

Generate:

✓ Missing screens

✓ Missing user flows

✓ Missing components

✓ Loading states

✓ Empty states

✓ Error states

✓ Success states

✓ Complete component library

✓ Interactive prototype

✓ Auto Layout

✓ Responsive layouts

✓ Design tokens

✓ Developer handoff ready

The final Figma project should feel like a complete production-ready mobile application ready for React Native implementation.
