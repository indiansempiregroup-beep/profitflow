# ProfitFlow — Complete Product Design System & Mobile Application UI

You are an award-winning Senior Product Designer, FinTech UX Designer, and Design System Architect.

Your task is to design the complete mobile application UI/UX for a premium cryptocurrency trading intelligence platform called **ProfitFlow**.

The design should feel polished enough to compete with products from Apple, Stripe, Robinhood, Revolut, Coinbase, Linear, and Notion.

This is NOT another crypto exchange.

This is a **Trading Intelligence Platform**.

The application helps traders discover profitable arbitrage opportunities across multiple cryptocurrency exchanges.

The UI must feel modern, elegant, premium, trustworthy, and extremely easy to use.

Every screen should immediately answer:

> "Is there a profitable opportunity right now?"

Avoid information overload.

Design for clarity.

Design for speed.

Design for confidence.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# DESIGN PHILOSOPHY

Minimal.

Premium.

Dark-first.

Modern FinTech.

Glassmorphism.

Soft gradients.

Rounded corners.

Beautiful typography.

Professional.

Data-driven.

No visual clutter.

Smooth motion.

High accessibility.

The application should feel like a blend of:

• Apple Wallet

• Revolut

• Robinhood

• Stripe Dashboard

• Linear

• Arc Browser

Not Binance.

Not CoinDCX.

Not TradingView.

Avoid generic crypto dashboard designs.

Create something unique.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# DESIGN SYSTEM

Generate a complete design system.

Typography

Spacing

Grid

Corner Radius

Elevation

Shadows

Glass Cards

Borders

Icons

Illustrations

Charts

Animations

Badges

Status Indicators

Cards

Buttons

Inputs

Tabs

Bottom Sheets

Dialogs

Snackbars

Tooltips

Skeleton Loaders

Empty States

Error States

Loading Screens

Success Screens

Accessibility

Dark Theme

Light Theme

Design Tokens

Component Variants

Responsive Behavior

Interaction States

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# COLOR PALETTE

Background

#0B0F19

Surface

#121826

Surface Elevated

#1A2234

Border

#273246

Primary

#5B8DEF

Success

#00D26A

Danger

#FF4D4F

Warning

#FFB020

Info

#4DA3FF

Text Primary

#FFFFFF

Text Secondary

#9AA4B2

Divider

#273246

Use subtle gradients.

Avoid neon colors.

Avoid oversaturated colors.

The application should feel premium.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# TYPOGRAPHY

Use a modern sans-serif font.

Clear hierarchy.

Large hero numbers.

Readable financial values.

Excellent spacing.

Support large accessibility text.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ICON STYLE

Minimal

Outlined

Rounded

Consistent stroke width

Professional

No cartoon icons

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# MOTION DESIGN

Use smooth animations.

Spring animations.

Micro interactions.

Subtle card elevation.

Animated numbers.

Animated loading states.

Animated transitions.

Animated tab switching.

Smooth pull-to-refresh.

Beautiful skeleton loading.

No excessive animations.

Everything should feel alive but never distracting.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# NAVIGATION

Bottom Navigation

Dashboard

Scanner

Portfolio

Insights

Settings

Support gesture navigation.

Support deep linking.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# MOBILE SCREENS

Design every screen.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AUTHENTICATION

Splash

Onboarding

Welcome

Login

Register

Forgot Password

Exchange Connection

Success

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DASHBOARD

Good Morning Header

Scanner Status

Today's Best Opportunity

Market Health

Portfolio Summary

Paper Trading Summary

Recent Opportunities

Performance Summary

Quick Actions

Live Status Indicators

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SCANNER

Scanner Overview

Opportunity List

Opportunity Card

Search

Filters

Sorting

Exchange Filter

Symbol Filter

Opportunity Detail

Opportunity Timeline

Liquidity

Spread

Confidence Score

Expected Profit

Fees

Risk

Paper Trade Button

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PORTFOLIO

Portfolio Overview

Total Value

Asset Allocation

Exchange Balances

Asset Detail

Performance

Profit/Loss

Portfolio History

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PAPER TRADING

Open Positions

Closed Positions

Trade History

Performance

ROI

Win Rate

Statistics

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INSIGHTS

Daily Insights

Weekly Insights

Monthly Insights

Scanner Statistics

Historical Opportunities

Market Trends

Exchange Performance

Profit Trends

Charts

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

NOTIFICATIONS

Opportunity Alerts

Scanner Alerts

Exchange Alerts

System Alerts

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SETTINGS

Profile

Theme

Notification Settings

Scanner Rules

API Keys

Exchange Management

Security

About

Version

Logs

Help

Privacy

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# DASHBOARD EXPERIENCE

The Dashboard must be the hero screen.

When users open the app they should instantly know:

Is the scanner running?

How many exchanges are connected?

What is the best opportunity?

How much estimated profit exists?

How healthy is the system?

The dashboard should require less than 5 seconds to understand.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# OPPORTUNITY CARD

Large beautiful card.

Show:

Symbol

Buy Exchange

Sell Exchange

Spread %

Estimated Profit

Confidence Score

Liquidity Indicator

Risk Indicator

Time Detected

Call-to-action button

The opportunity should feel exciting.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# OPPORTUNITY DETAILS

Beautiful hero section.

Timeline.

Buy Price.

Sell Price.

Trading Fees.

Withdrawal Fees.

Liquidity.

Confidence.

Historical Trend.

Paper Trade CTA.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# PORTFOLIO EXPERIENCE

Modern cards.

Large portfolio value.

Beautiful allocation charts.

Asset cards.

Daily gain/loss.

Exchange balances.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# INSIGHTS

Do not overwhelm users with charts.

Explain information.

Examples:

"BTC spread has remained above 0.7% for the last 24 minutes."

"ETH opportunities have increased by 18% today."

"CoinDCX currently provides the highest average spread."

Focus on intelligent storytelling.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# EMPTY STATES

Create beautiful illustrations.

Friendly messaging.

Helpful guidance.

Clear actions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# LOADING STATES

Skeleton loaders.

Animated placeholders.

Shimmer effects.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ERROR STATES

Elegant.

Helpful.

Never technical.

Clear recovery actions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ACCESSIBILITY

High contrast.

Large touch targets.

Screen reader support.

Dynamic text.

Keyboard navigation where appropriate.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# DELIVERABLES

Generate:

• Complete Design System

• Component Library

• Mobile Design Kit

• User Flow

• Navigation Map

• Every Mobile Screen

• Every Empty State

• Every Loading State

• Every Error State

• Dark Theme

• Light Theme

• Interactive Prototype

• Auto Layout Components

• Design Tokens

• Developer Handoff Ready

The final result should feel like a premium fintech application that could be featured by Apple or Google for its exceptional design quality.
