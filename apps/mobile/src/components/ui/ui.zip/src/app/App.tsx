import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  LayoutDashboard, Radar, Briefcase, BarChart3, Settings,
  TrendingUp, ArrowRightLeft, Zap, Bell, ChevronRight,
  RefreshCw, Shield, Wifi, WifiOff, Clock, Star, Filter,
  Search, X, ArrowUpRight, ArrowDownRight, Activity, Globe,
  Lock, Moon, HelpCircle, LogOut, User, Eye, EyeOff,
  CheckCircle2, AlertCircle, AlertTriangle, Bookmark,
  Share2, ChevronLeft, Mail, Key, Trash2, BarChart2,
  Wallet, History, Check, Sun, FileText, Cpu,
  SlidersHorizontal, TrendingDown, Plus, Fingerprint,
  Languages, Info, Target, Award,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar,
} from "recharts";

// ─── Colors ───────────────────────────────────────────────────────────────────
const C = {
  bg: "#0B0F19", surface: "#121826", elevated: "#1A2234", border: "#273246",
  primary: "#5B8DEF", success: "#00D26A", danger: "#FF4D4F",
  warning: "#FFB020", info: "#4DA3FF",
  textPrimary: "#FFFFFF", textSecondary: "#9AA4B2",
};

// ─── Types ────────────────────────────────────────────────────────────────────
type AuthStep = "splash" | "welcome" | "login" | "register" | "forgot" | "verify" | "success" | "exchange-setup";
type MainTab = "dashboard" | "scanner" | "portfolio" | "insights" | "settings";
type PortfolioTab = "assets" | "trading" | "history";
type TradingTab = "open" | "closed" | "stats";
type SettingsSub = null | "profile" | "exchanges" | "exchange-connect";

// ─── Data ─────────────────────────────────────────────────────────────────────
const opportunities = [
  { id: 1, symbol: "BTC/USDT", buyExchange: "Binance", sellExchange: "CoinDCX", spread: 1.24, profit: 312.40, confidence: 94, liquidity: "High", risk: "Low", detected: "2m ago", trending: true },
  { id: 2, symbol: "ETH/USDT", buyExchange: "Kraken", sellExchange: "Coinbase", spread: 0.87, profit: 142.60, confidence: 88, liquidity: "High", risk: "Low", detected: "5m ago", trending: true },
  { id: 3, symbol: "SOL/USDT", buyExchange: "OKX", sellExchange: "Bybit", spread: 0.62, profit: 89.20, confidence: 76, liquidity: "Medium", risk: "Medium", detected: "9m ago", trending: false },
  { id: 4, symbol: "BNB/USDT", buyExchange: "Gate.io", sellExchange: "Huobi", spread: 0.51, profit: 67.80, confidence: 71, liquidity: "Medium", risk: "Medium", detected: "14m ago", trending: false },
  { id: 5, symbol: "XRP/USDT", buyExchange: "Bitstamp", sellExchange: "Kraken", spread: 0.43, profit: 43.10, confidence: 65, liquidity: "Low", risk: "High", detected: "21m ago", trending: false },
];

const notificationsData = [
  { id: 1, type: "opportunity", icon: TrendingUp, color: C.success, title: "New BTC/USDT Opportunity", body: "1.24% spread detected between Binance and CoinDCX", time: "2m ago", read: false },
  { id: 2, type: "opportunity", icon: TrendingUp, color: C.success, title: "New ETH/USDT Opportunity", body: "0.87% spread on Kraken vs Coinbase — $142 est. profit", time: "5m ago", read: false },
  { id: 3, type: "scanner", icon: Radar, color: C.primary, title: "Scanner Alert", body: "BTC spread has been above 0.7% for 24 consecutive minutes", time: "18m ago", read: false },
  { id: 4, type: "exchange", icon: Wifi, color: C.info, title: "Binance Connected", body: "Exchange reconnected and syncing balances", time: "1h ago", read: true },
  { id: 5, type: "security", icon: Shield, color: C.warning, title: "New Login Detected", body: "Login from MacOS Safari — if this was you, no action needed", time: "3h ago", read: true },
  { id: 6, type: "system", icon: Info, color: C.textSecondary, title: "Scanner Updated", body: "New v2.4 rules applied. Detection accuracy improved by 8%", time: "1d ago", read: true },
];

const openPositions = [
  { id: 1, symbol: "BTC/USDT", buyEx: "Binance", sellEx: "CoinDCX", spread: 1.24, size: 1000, opened: "2h ago", currentProfit: 89.40 },
  { id: 2, symbol: "ETH/USDT", buyEx: "Kraken", sellEx: "Coinbase", spread: 0.87, size: 500, opened: "45m ago", currentProfit: 32.60 },
];

const closedPositions = [
  { id: 3, symbol: "BNB/USDT", buyEx: "Gate.io", sellEx: "Huobi", profit: 142.80, pnlPct: 17.8, closed: "1d ago", size: 800 },
  { id: 4, symbol: "SOL/USDT", buyEx: "OKX", sellEx: "Bybit", profit: -18.40, pnlPct: -6.1, closed: "2d ago", size: 300 },
  { id: 5, symbol: "XRP/USDT", buyEx: "Bitstamp", sellEx: "Kraken", profit: 67.20, pnlPct: 16.8, closed: "3d ago", size: 400 },
  { id: 6, symbol: "BTC/USDT", buyEx: "Coinbase", sellEx: "Huobi", profit: 210.60, pnlPct: 21.1, closed: "4d ago", size: 1000 },
];

const equityCurve = [
  { day: "Day 1", value: 1000 }, { day: "Day 5", value: 1120 }, { day: "Day 10", value: 1080 },
  { day: "Day 15", value: 1290 }, { day: "Day 20", value: 1380 }, { day: "Day 25", value: 1520 },
  { day: "Day 30", value: 1842 },
];

const portfolioAssets = [
  { name: "Bitcoin", symbol: "BTC", value: 18420.50, change: 2.4, color: "#F7931A", pct: 48 },
  { name: "Ethereum", symbol: "ETH", value: 9210.00, change: -0.8, color: "#627EEA", pct: 24 },
  { name: "Solana", symbol: "SOL", value: 4605.25, change: 5.1, color: "#9945FF", pct: 12 },
  { name: "Binance Coin", symbol: "BNB", value: 3070.75, change: 1.3, color: "#F3BA2F", pct: 8 },
  { name: "Other", symbol: "–", value: 3070.00, change: 0.4, color: "#273246", pct: 8 },
];

const performanceData = [
  { day: "Mon", profit: 120 }, { day: "Tue", profit: 280 }, { day: "Wed", profit: 190 },
  { day: "Thu", profit: 420 }, { day: "Fri", profit: 360 }, { day: "Sat", profit: 540 }, { day: "Sun", profit: 312 },
];

const spreadHistory = [
  { time: "00:00", btc: 0.8, eth: 0.5 }, { time: "04:00", btc: 1.1, eth: 0.7 },
  { time: "08:00", btc: 0.9, eth: 0.6 }, { time: "12:00", btc: 1.4, eth: 0.9 },
  { time: "16:00", btc: 1.2, eth: 0.8 }, { time: "20:00", btc: 1.24, eth: 0.87 },
];

const insights = [
  { icon: TrendingUp, color: C.success, label: "BTC spread has remained above 0.7% for the last 24 minutes", tag: "Opportunity" },
  { icon: Activity, color: C.primary, label: "ETH opportunities have increased by 18% today", tag: "Trend" },
  { icon: Star, color: C.warning, label: "CoinDCX currently provides the highest average spread", tag: "Top Exchange" },
  { icon: Shield, color: C.info, label: "Market volatility is low — ideal conditions for arbitrage", tag: "Market" },
  { icon: Target, color: C.success, label: "Your scanner detected 47 opportunities in the last 6 hours", tag: "Scanner" },
];

const exchangeList = [
  { id: "binance", name: "Binance", tag: "Most Popular", color: "#F3BA2F", connected: true },
  { id: "coindcx", name: "CoinDCX", tag: "India", color: "#1A6AFF", connected: true },
  { id: "bybit", name: "Bybit", tag: "Coming Soon", color: "#F7A600", connected: false, soon: true },
  { id: "okx", name: "OKX", tag: "Global", color: "#FFFFFF", connected: false },
  { id: "kraken", name: "Kraken", tag: "Trusted", color: "#5741D9", connected: false },
  { id: "kucoin", name: "KuCoin", tag: "Altcoins", color: "#23AF91", connected: false },
];

const txHistory = [
  { id: 1, type: "deposit", asset: "USDT", amount: "+5,000.00", exchange: "Binance", date: "Jun 25", color: C.success },
  { id: 2, type: "trade", asset: "BTC", amount: "-0.12", exchange: "Coinbase", date: "Jun 24", color: C.danger },
  { id: 3, type: "deposit", asset: "ETH", amount: "+2.40", exchange: "Kraken", date: "Jun 22", color: C.success },
  { id: 4, type: "withdrawal", asset: "USDT", amount: "-800.00", exchange: "Binance", date: "Jun 20", color: C.danger },
];

// ─── Utility Components ───────────────────────────────────────────────────────
function Badge({ label, color, bg }: { label: string; color: string; bg: string }) {
  return (
    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full font-mono uppercase tracking-wider" style={{ color, backgroundColor: bg }}>
      {label}
    </span>
  );
}

function GlassCard({ children, className = "", onClick }: { children: React.ReactNode; className?: string; onClick?: () => void }) {
  return (
    <motion.div whileTap={onClick ? { scale: 0.98 } : {}} onClick={onClick}
      className={`rounded-2xl border ${className}`} style={{ backgroundColor: C.surface, borderColor: C.border }}>
      {children}
    </motion.div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: C.textSecondary }}>{children}</p>;
}

function ConfidenceBar({ value, color }: { value: number; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full" style={{ backgroundColor: C.border }}>
        <motion.div className="h-full rounded-full" style={{ backgroundColor: color }}
          initial={{ width: 0 }} animate={{ width: `${value}%` }} transition={{ duration: 0.8, ease: "easeOut" }} />
      </div>
      <span className="text-xs font-mono font-semibold" style={{ color }}>{value}%</span>
    </div>
  );
}

function StatPill({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="flex flex-col gap-0.5 items-center">
      <span className="text-[11px]" style={{ color: C.textSecondary }}>{label}</span>
      <span className="text-sm font-semibold font-mono" style={{ color: color || C.textPrimary }}>{value}</span>
    </div>
  );
}

function BackButton({ onBack }: { onBack: () => void }) {
  return (
    <motion.button whileTap={{ scale: 0.9 }} onClick={onBack}
      className="w-9 h-9 rounded-full flex items-center justify-center border"
      style={{ backgroundColor: C.elevated, borderColor: C.border }}>
      <ChevronLeft size={16} style={{ color: C.textSecondary }} />
    </motion.button>
  );
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────
function Shimmer({ className = "" }: { className?: string }) {
  return <div className={`animate-pulse rounded-xl ${className}`} style={{ backgroundColor: C.elevated }} />;
}

function SkeletonCard() {
  return (
    <div className="rounded-2xl border p-4 flex flex-col gap-3" style={{ backgroundColor: C.surface, borderColor: C.border }}>
      <div className="flex justify-between">
        <div className="flex flex-col gap-2"><Shimmer className="w-24 h-4" /><Shimmer className="w-16 h-3" /></div>
        <Shimmer className="w-14 h-8" />
      </div>
      <div className="flex justify-between"><Shimmer className="w-20 h-5" /><Shimmer className="w-28 h-3" /></div>
      <div className="flex gap-2"><Shimmer className="w-24 h-5" /><Shimmer className="w-20 h-5" /></div>
    </div>
  );
}

function SkeletonList() {
  return (
    <div className="flex flex-col gap-3">
      {[0, 1, 2].map(i => <SkeletonCard key={i} />)}
    </div>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────
function EmptyState({ icon: Icon, color = C.primary, title, body, ctaLabel, onCta }: {
  icon: React.ElementType; color?: string; title: string; body: string; ctaLabel?: string; onCta?: () => void;
}) {
  return (
    <div className="flex flex-col items-center py-16 px-6 gap-4 text-center">
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ backgroundColor: color + "18" }}>
        <Icon size={28} style={{ color }} />
      </div>
      <div>
        <div className="text-base font-semibold mb-1.5" style={{ color: C.textPrimary }}>{title}</div>
        <div className="text-sm leading-relaxed" style={{ color: C.textSecondary }}>{body}</div>
      </div>
      {ctaLabel && onCta && (
        <motion.button whileTap={{ scale: 0.96 }} onClick={onCta}
          className="mt-2 px-6 py-2.5 rounded-xl text-sm font-semibold"
          style={{ backgroundColor: C.primary, color: "#fff" }}>
          {ctaLabel}
        </motion.button>
      )}
    </div>
  );
}

// ─── Error State ──────────────────────────────────────────────────────────────
function ErrorState({ type, onRetry }: { type: "offline" | "api" | "auth" | "rate-limit"; onRetry?: () => void }) {
  const config = {
    offline: { icon: WifiOff, color: C.textSecondary, title: "No Connection", body: "ProfitFlow needs an internet connection to scan for opportunities. Check your network and try again." },
    api: { icon: AlertCircle, color: C.danger, title: "Something Went Wrong", body: "We couldn't load the data right now. Our team has been notified. Please try again in a moment." },
    auth: { icon: Lock, color: C.warning, title: "Session Expired", body: "Your session has timed out for security. Please sign in again to continue." },
    "rate-limit": { icon: Clock, color: C.warning, title: "Too Many Requests", body: "Your exchange API rate limit was reached. Scanner will resume automatically in a few seconds." },
  };
  const { icon: Icon, color, title, body } = config[type];
  return (
    <div className="flex flex-col items-center py-14 px-6 gap-4 text-center">
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ backgroundColor: color + "18" }}>
        <Icon size={28} style={{ color }} />
      </div>
      <div>
        <div className="text-base font-semibold mb-1.5" style={{ color: C.textPrimary }}>{title}</div>
        <div className="text-sm leading-relaxed" style={{ color: C.textSecondary }}>{body}</div>
      </div>
      {onRetry && (
        <motion.button whileTap={{ scale: 0.96 }} onClick={onRetry}
          className="mt-2 px-6 py-2.5 rounded-xl text-sm font-semibold border"
          style={{ backgroundColor: "transparent", borderColor: C.border, color: C.textSecondary }}>
          Try Again
        </motion.button>
      )}
    </div>
  );
}

// ─── AUTH: Splash ─────────────────────────────────────────────────────────────
function SplashScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const start = Date.now();
    const tick = setInterval(() => {
      const pct = Math.min((Date.now() - start) / 2200, 1);
      setProgress(pct);
      if (pct >= 1) { clearInterval(tick); setTimeout(onDone, 200); }
    }, 16);
    return () => clearInterval(tick);
  }, [onDone]);

  return (
    <div className="flex flex-col items-center justify-center h-full gap-6" style={{
      background: `radial-gradient(ellipse at 50% 30%, #1a2a4a 0%, ${C.bg} 65%)`
    }}>
      <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
        className="flex flex-col items-center gap-4">
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center"
          style={{ background: `linear-gradient(135deg, ${C.primary}, ${C.info})` }}>
          <TrendingUp size={36} color="#fff" />
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold tracking-tight" style={{ color: C.textPrimary }}>ProfitFlow</div>
          <div className="text-sm mt-1" style={{ color: C.textSecondary }}>Trading Intelligence Platform</div>
        </div>
      </motion.div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        className="w-48 h-1 rounded-full overflow-hidden" style={{ backgroundColor: C.border }}>
        <motion.div className="h-full rounded-full" style={{ backgroundColor: C.primary, width: `${progress * 100}%` }} />
      </motion.div>
    </div>
  );
}

// ─── AUTH: Welcome ────────────────────────────────────────────────────────────
function WelcomeScreen({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) {
  return (
    <div className="flex flex-col justify-between h-full px-6 pb-8 pt-16">
      <div className="flex flex-col items-center gap-6 text-center">
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
          style={{ background: `linear-gradient(135deg, ${C.primary}, ${C.info})` }}>
          <TrendingUp size={28} color="#fff" />
        </div>
        <div>
          <div className="text-3xl font-bold mb-2" style={{ color: C.textPrimary }}>Welcome to<br />ProfitFlow</div>
          <div className="text-sm leading-relaxed" style={{ color: C.textSecondary }}>
            Discover profitable arbitrage opportunities across the world's top crypto exchanges.
          </div>
        </div>
        <div className="w-full rounded-2xl overflow-hidden" style={{ height: 180, backgroundColor: C.elevated }}>
          <div className="w-full h-full flex items-center justify-center relative">
            <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 50% 50%, ${C.primary}22, transparent)` }} />
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={performanceData} margin={{ top: 16, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="welcome-grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={C.primary} stopOpacity={0.4} />
                    <stop offset="95%" stopColor={C.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area key="welcome-area" type="monotone" dataKey="profit" stroke={C.primary} strokeWidth={2} fill="url(#welcome-grad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-3">
        <div className="flex gap-3 mb-1">
          {[{ icon: Globe, label: "Google" }, { icon: Award, label: "Apple" }].map(s => (
            <motion.button key={s.label} whileTap={{ scale: 0.96 }}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border text-sm font-semibold"
              style={{ backgroundColor: C.elevated, borderColor: C.border, color: C.textPrimary }}>
              <s.icon size={15} /> {s.label}
            </motion.button>
          ))}
        </div>
        <div className="flex items-center gap-3 my-1">
          <div className="flex-1 h-px" style={{ backgroundColor: C.border }} />
          <span className="text-xs" style={{ color: C.textSecondary }}>or</span>
          <div className="flex-1 h-px" style={{ backgroundColor: C.border }} />
        </div>
        <motion.button whileTap={{ scale: 0.97 }} onClick={onLogin}
          className="w-full py-3.5 rounded-2xl text-sm font-bold"
          style={{ backgroundColor: C.primary, color: "#fff" }}>
          Sign In with Email
        </motion.button>
        <motion.button whileTap={{ scale: 0.97 }} onClick={onRegister}
          className="w-full py-3.5 rounded-2xl text-sm font-semibold border"
          style={{ backgroundColor: "transparent", borderColor: C.border, color: C.textPrimary }}>
          Create Account
        </motion.button>
      </div>
    </div>
  );
}

// ─── AUTH: Login ──────────────────────────────────────────────────────────────
function LoginScreen({ onSuccess, onRegister, onForgot, onBack }: {
  onSuccess: () => void; onRegister: () => void; onForgot: () => void; onBack: () => void;
}) {
  const [email, setEmail] = useState("alex@profitflow.io");
  const [password, setPassword] = useState("••••••••");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = () => {
    if (!email) { setError("Please enter your email address."); return; }
    setError(""); setLoading(true);
    setTimeout(() => { setLoading(false); onSuccess(); }, 1400);
  };

  return (
    <div className="flex flex-col h-full px-6 pb-8 pt-6">
      <div className="flex items-center gap-3 mb-8"><BackButton onBack={onBack} />
        <div><div className="text-lg font-bold" style={{ color: C.textPrimary }}>Sign In</div>
          <div className="text-xs" style={{ color: C.textSecondary }}>Welcome back</div></div>
      </div>
      <div className="flex flex-col gap-4 flex-1">
        <div>
          <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>Email Address</div>
          <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Mail size={15} style={{ color: C.textSecondary }} />
            <input value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"
              className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
          </div>
        </div>
        <div>
          <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>Password</div>
          <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Lock size={15} style={{ color: C.textSecondary }} />
            <input value={password} onChange={e => setPassword(e.target.value)} type={showPass ? "text" : "password"}
              placeholder="Enter password" className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowPass(v => !v)}>
              {showPass ? <EyeOff size={15} style={{ color: C.textSecondary }} /> : <Eye size={15} style={{ color: C.textSecondary }} />}
            </motion.button>
          </div>
        </div>
        {error && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ backgroundColor: C.danger + "18" }}>
            <AlertCircle size={13} style={{ color: C.danger }} />
            <span className="text-xs" style={{ color: C.danger }}>{error}</span>
          </div>
        )}
        <motion.button whileTap={{ scale: 0.95 }} onClick={onForgot}
          className="text-xs self-end" style={{ color: C.primary }}>Forgot Password?</motion.button>
        <motion.button whileTap={{ scale: 0.96 }} onClick={handleSubmit} disabled={loading}
          className="w-full py-3.5 rounded-2xl text-sm font-bold flex items-center justify-center gap-2"
          style={{ backgroundColor: C.primary, color: "#fff", opacity: loading ? 0.8 : 1 }}>
          {loading ? <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}>
            <RefreshCw size={16} /></motion.div> : "Sign In"}
        </motion.button>
        <div className="flex items-center justify-center gap-2 py-3 rounded-xl border mt-1"
          style={{ backgroundColor: C.elevated, borderColor: C.border }}>
          <Fingerprint size={18} style={{ color: C.primary }} />
          <span className="text-sm" style={{ color: C.textPrimary }}>Use Biometric</span>
        </div>
      </div>
      <div className="text-center text-sm mt-4" style={{ color: C.textSecondary }}>
        Don&apos;t have an account?{" "}
        <motion.button whileTap={{ scale: 0.95 }} onClick={onRegister}
          className="font-semibold" style={{ color: C.primary }}>Create one</motion.button>
      </div>
    </div>
  );
}

// ─── AUTH: Register ───────────────────────────────────────────────────────────
function RegisterScreen({ onNext, onLogin, onBack }: { onNext: () => void; onLogin: () => void; onBack: () => void }) {
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); onNext(); }, 1200);
  };

  return (
    <div className="flex flex-col h-full px-6 pb-8 pt-6">
      <div className="flex items-center gap-3 mb-8"><BackButton onBack={onBack} />
        <div><div className="text-lg font-bold" style={{ color: C.textPrimary }}>Create Account</div>
          <div className="text-xs" style={{ color: C.textSecondary }}>Join ProfitFlow</div></div>
      </div>
      <div className="flex flex-col gap-4 flex-1">
        {[
          { label: "Full Name", placeholder: "Alex Johnson", type: "text", icon: User },
          { label: "Email Address", placeholder: "you@example.com", type: "email", icon: Mail },
        ].map(f => (
          <div key={f.label}>
            <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>{f.label}</div>
            <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
              style={{ backgroundColor: C.elevated, borderColor: C.border }}>
              <f.icon size={15} style={{ color: C.textSecondary }} />
              <input placeholder={f.placeholder} type={f.type}
                className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
            </div>
          </div>
        ))}
        <div>
          <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>Password</div>
          <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Lock size={15} style={{ color: C.textSecondary }} />
            <input type={showPass ? "text" : "password"} placeholder="Create password"
              className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowPass(v => !v)}>
              {showPass ? <EyeOff size={15} style={{ color: C.textSecondary }} /> : <Eye size={15} style={{ color: C.textSecondary }} />}
            </motion.button>
          </div>
        </div>
        <motion.button whileTap={{ scale: 0.96 }} onClick={handleSubmit} disabled={loading}
          className="w-full py-3.5 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 mt-2"
          style={{ backgroundColor: C.primary, color: "#fff" }}>
          {loading ? <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}>
            <RefreshCw size={16} /></motion.div> : "Create Account"}
        </motion.button>
        <p className="text-xs text-center mt-1" style={{ color: C.textSecondary }}>
          By continuing you agree to our <span style={{ color: C.primary }}>Terms</span> and <span style={{ color: C.primary }}>Privacy Policy</span>
        </p>
      </div>
      <div className="text-center text-sm" style={{ color: C.textSecondary }}>
        Already have an account?{" "}
        <motion.button whileTap={{ scale: 0.95 }} onClick={onLogin}
          className="font-semibold" style={{ color: C.primary }}>Sign in</motion.button>
      </div>
    </div>
  );
}

// ─── AUTH: Forgot Password ────────────────────────────────────────────────────
function ForgotPasswordScreen({ onBack, onSent }: { onBack: () => void; onSent: () => void }) {
  const [loading, setLoading] = useState(false);
  const handleSend = () => { setLoading(true); setTimeout(() => { setLoading(false); onSent(); }, 1200); };
  return (
    <div className="flex flex-col h-full px-6 pb-8 pt-6">
      <div className="flex items-center gap-3 mb-8"><BackButton onBack={onBack} />
        <div><div className="text-lg font-bold" style={{ color: C.textPrimary }}>Reset Password</div>
          <div className="text-xs" style={{ color: C.textSecondary }}>We'll send a code to your email</div></div>
      </div>
      <div className="flex flex-col gap-4">
        <div>
          <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>Email Address</div>
          <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Mail size={15} style={{ color: C.textSecondary }} />
            <input placeholder="you@example.com" className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
          </div>
        </div>
        <motion.button whileTap={{ scale: 0.96 }} onClick={handleSend} disabled={loading}
          className="w-full py-3.5 rounded-2xl text-sm font-bold flex items-center justify-center gap-2"
          style={{ backgroundColor: C.primary, color: "#fff" }}>
          {loading ? <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}>
            <RefreshCw size={16} /></motion.div> : "Send Reset Link"}
        </motion.button>
      </div>
    </div>
  );
}

// ─── AUTH: Verify OTP ─────────────────────────────────────────────────────────
function VerifyScreen({ onVerified, onBack }: { onVerified: () => void; onBack: () => void }) {
  const [digits, setDigits] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([null, null, null, null, null, null]);

  const handleChange = (i: number, val: string) => {
    const d = [...digits]; d[i] = val.slice(-1); setDigits(d);
    if (val && i < 5) inputRefs.current[i + 1]?.focus();
  };
  const handleKeyDown = (i: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !digits[i] && i > 0) inputRefs.current[i - 1]?.focus();
  };
  const handleVerify = () => { setLoading(true); setTimeout(() => { setLoading(false); onVerified(); }, 1200); };
  const complete = digits.every(d => d !== "");

  return (
    <div className="flex flex-col h-full px-6 pb-8 pt-6">
      <div className="flex items-center gap-3 mb-8"><BackButton onBack={onBack} />
        <div><div className="text-lg font-bold" style={{ color: C.textPrimary }}>Verify Email</div>
          <div className="text-xs" style={{ color: C.textSecondary }}>Enter the 6-digit code we sent</div></div>
      </div>
      <div className="flex flex-col gap-6">
        <div className="flex gap-2 justify-center">
          {digits.map((d, i) => (
            <input key={i} ref={el => { inputRefs.current[i] = el; }}
              value={d} onChange={e => handleChange(i, e.target.value)}
              onKeyDown={e => handleKeyDown(i, e)}
              maxLength={1} inputMode="numeric"
              className="w-11 h-14 rounded-xl border text-center text-xl font-bold outline-none"
              style={{
                backgroundColor: C.elevated, borderColor: d ? C.primary : C.border,
                color: C.textPrimary, fontFamily: "JetBrains Mono, monospace",
              }} />
          ))}
        </div>
        <p className="text-xs text-center" style={{ color: C.textSecondary }}>
          Didn&apos;t receive it? <span style={{ color: C.primary }}>Resend code</span>
        </p>
        <motion.button whileTap={{ scale: 0.96 }} onClick={handleVerify}
          disabled={!complete || loading}
          className="w-full py-3.5 rounded-2xl text-sm font-bold flex items-center justify-center gap-2"
          style={{ backgroundColor: C.primary, color: "#fff", opacity: complete ? 1 : 0.5 }}>
          {loading ? <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}>
            <RefreshCw size={16} /></motion.div> : "Verify & Continue"}
        </motion.button>
      </div>
    </div>
  );
}

// ─── AUTH: Success ────────────────────────────────────────────────────────────
function AuthSuccessScreen({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="flex flex-col h-full items-center justify-center px-6 pb-8 gap-8">
      <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 16 }}
        className="w-24 h-24 rounded-full flex items-center justify-center"
        style={{ backgroundColor: C.success + "22", border: `2px solid ${C.success}` }}>
        <Check size={40} style={{ color: C.success }} />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        className="text-center">
        <div className="text-2xl font-bold mb-2" style={{ color: C.textPrimary }}>You&apos;re in!</div>
        <div className="text-sm leading-relaxed" style={{ color: C.textSecondary }}>
          Your account is ready. Let&apos;s connect your first exchange to start scanning for opportunities.
        </div>
      </motion.div>
      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        whileTap={{ scale: 0.97 }} onClick={onContinue}
        className="w-full py-3.5 rounded-2xl text-sm font-bold"
        style={{ backgroundColor: C.primary, color: "#fff" }}>
        Connect an Exchange
      </motion.button>
      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}
        whileTap={{ scale: 0.97 }} onClick={onContinue}
        className="text-sm" style={{ color: C.textSecondary }}>
        Skip for now
      </motion.button>
    </div>
  );
}

// ─── AUTH: Exchange Setup ─────────────────────────────────────────────────────
function ExchangeSetupScreen({ onDone }: { onDone: () => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [connectStep, setConnectStep] = useState<"list" | "apikey" | "secret" | "testing" | "done">("list");
  const [apiKey, setApiKey] = useState("");
  const [secret, setSecret] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [showSecret, setShowSecret] = useState(false);

  const handleTest = () => {
    setConnectStep("testing");
    setTimeout(() => setConnectStep("done"), 1800);
  };

  if (connectStep === "done") {
    return (
      <div className="flex flex-col h-full items-center justify-center px-6 gap-8">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200 }}
          className="w-20 h-20 rounded-full flex items-center justify-center" style={{ backgroundColor: C.success + "22" }}>
          <CheckCircle2 size={36} style={{ color: C.success }} />
        </motion.div>
        <div className="text-center">
          <div className="text-xl font-bold mb-2" style={{ color: C.textPrimary }}>{selected} Connected!</div>
          <div className="text-sm" style={{ color: C.textSecondary }}>Your exchange is live. Scanner will begin shortly.</div>
        </div>
        <motion.button whileTap={{ scale: 0.97 }} onClick={onDone}
          className="w-full py-3.5 rounded-2xl text-sm font-bold"
          style={{ backgroundColor: C.primary, color: "#fff" }}>
          Go to Dashboard
        </motion.button>
      </div>
    );
  }

  if (connectStep === "testing") {
    return (
      <div className="flex flex-col h-full items-center justify-center px-6 gap-6">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}>
          <RefreshCw size={36} style={{ color: C.primary }} />
        </motion.div>
        <div className="text-center">
          <div className="text-lg font-bold mb-1" style={{ color: C.textPrimary }}>Testing Connection</div>
          <div className="text-sm" style={{ color: C.textSecondary }}>Verifying your API keys with {selected}…</div>
        </div>
      </div>
    );
  }

  if (connectStep === "apikey" || connectStep === "secret") {
    return (
      <div className="flex flex-col h-full px-6 pb-8 pt-6">
        <div className="flex items-center gap-3 mb-6">
          <BackButton onBack={() => setConnectStep(connectStep === "apikey" ? "list" : "apikey")} />
          <div>
            <div className="text-lg font-bold" style={{ color: C.textPrimary }}>Connect {selected}</div>
            <div className="text-xs" style={{ color: C.textSecondary }}>
              Step {connectStep === "apikey" ? "1" : "2"} of 2
            </div>
          </div>
        </div>
        <div className="rounded-2xl border p-4 mb-6" style={{ backgroundColor: C.elevated, borderColor: C.border }}>
          <div className="flex items-start gap-3">
            <Info size={16} style={{ color: C.info }} />
            <div className="text-xs leading-relaxed" style={{ color: C.textSecondary }}>
              {connectStep === "apikey"
                ? `Go to ${selected} → API Management → Create API Key. Enable "Read Only" permissions only. Do not enable withdrawals.`
                : "Copy the Secret key shown immediately after creating your API key. It will not be shown again."}
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-4 flex-1">
          {connectStep === "apikey" ? (
            <div>
              <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>API Key</div>
              <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
                style={{ backgroundColor: C.elevated, borderColor: C.border }}>
                <Key size={15} style={{ color: C.textSecondary }} />
                <input value={apiKey} onChange={e => setApiKey(e.target.value)}
                  type={showKey ? "text" : "password"} placeholder="Paste your API key"
                  className="flex-1 bg-transparent text-sm outline-none font-mono" style={{ color: C.textPrimary }} />
                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowKey(v => !v)}>
                  {showKey ? <EyeOff size={14} style={{ color: C.textSecondary }} /> : <Eye size={14} style={{ color: C.textSecondary }} />}
                </motion.button>
              </div>
            </div>
          ) : (
            <div>
              <div className="text-xs font-semibold mb-2" style={{ color: C.textSecondary }}>Secret Key</div>
              <div className="flex items-center gap-2 px-3 rounded-xl border h-12"
                style={{ backgroundColor: C.elevated, borderColor: C.border }}>
                <Lock size={15} style={{ color: C.textSecondary }} />
                <input value={secret} onChange={e => setSecret(e.target.value)}
                  type={showSecret ? "text" : "password"} placeholder="Paste your Secret key"
                  className="flex-1 bg-transparent text-sm outline-none font-mono" style={{ color: C.textPrimary }} />
                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowSecret(v => !v)}>
                  {showSecret ? <EyeOff size={14} style={{ color: C.textSecondary }} /> : <Eye size={14} style={{ color: C.textSecondary }} />}
                </motion.button>
              </div>
            </div>
          )}
          <motion.button whileTap={{ scale: 0.97 }}
            onClick={() => connectStep === "apikey" ? setConnectStep("secret") : handleTest()}
            className="w-full py-3.5 rounded-2xl text-sm font-bold mt-auto"
            style={{ backgroundColor: C.primary, color: "#fff" }}>
            {connectStep === "apikey" ? "Next: Secret Key" : "Test Connection"}
          </motion.button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full px-6 pb-8 pt-6">
      <div className="mb-6">
        <div className="text-xl font-bold mb-1" style={{ color: C.textPrimary }}>Connect Exchange</div>
        <div className="text-sm" style={{ color: C.textSecondary }}>Choose an exchange to start scanning</div>
      </div>
      <div className="grid grid-cols-2 gap-3 flex-1">
        {exchangeList.map(ex => (
          <motion.button key={ex.id} whileTap={{ scale: 0.96 }}
            onClick={() => { if (!ex.soon) { setSelected(ex.name); setConnectStep("apikey"); } }}
            className="rounded-2xl border p-4 flex flex-col gap-2 relative overflow-hidden text-left"
            style={{
              backgroundColor: ex.connected ? C.primary + "18" : C.elevated,
              borderColor: ex.connected ? C.primary + "55" : C.border,
              opacity: ex.soon ? 0.5 : 1,
            }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-base font-bold"
              style={{ backgroundColor: ex.color + "22", color: ex.color }}>{ex.logo}</div>
            <div className="text-sm font-semibold" style={{ color: C.textPrimary }}>{ex.name}</div>
            <div className="text-xs" style={{ color: ex.connected ? C.success : C.textSecondary }}>
              {ex.connected ? "Connected" : ex.soon ? "Soon" : ex.tag}
            </div>
            {ex.connected && (
              <div className="absolute top-3 right-3 w-2 h-2 rounded-full" style={{ backgroundColor: C.success }} />
            )}
          </motion.button>
        ))}
      </div>
      <motion.button whileTap={{ scale: 0.97 }} onClick={onDone}
        className="w-full py-3 rounded-2xl text-sm font-semibold border mt-4"
        style={{ backgroundColor: "transparent", borderColor: C.border, color: C.textSecondary }}>
        Skip for now
      </motion.button>
    </div>
  );
}

// ─── OVERLAY: Notifications ───────────────────────────────────────────────────
function NotificationPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [items, setItems] = useState(notificationsData);
  const [filter, setFilter] = useState("all");
  const types = ["all", "opportunity", "scanner", "exchange", "security"];
  const unread = items.filter(i => !i.read).length;

  const markAll = () => setItems(prev => prev.map(i => ({ ...i, read: true })));
  const remove = (id: number) => setItems(prev => prev.filter(i => i.id !== id));
  const filtered = filter === "all" ? items : items.filter(i => i.type === filter);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose} className="absolute inset-0 z-40" style={{ backgroundColor: "rgba(0,0,0,0.5)" }} />
          <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 35 }}
            className="absolute top-0 right-0 h-full z-50 flex flex-col"
            style={{ width: "88%", backgroundColor: C.surface, borderLeft: `1px solid ${C.border}` }}>
            <div className="flex items-center justify-between px-5 pt-12 pb-4">
              <div>
                <div className="text-base font-bold" style={{ color: C.textPrimary }}>Notifications</div>
                {unread > 0 && <div className="text-xs" style={{ color: C.textSecondary }}>{unread} unread</div>}
              </div>
              <div className="flex items-center gap-2">
                {unread > 0 && (
                  <motion.button whileTap={{ scale: 0.9 }} onClick={markAll}
                    className="text-xs px-2 py-1 rounded-lg" style={{ backgroundColor: C.elevated, color: C.primary }}>
                    Mark all read
                  </motion.button>
                )}
                <motion.button whileTap={{ scale: 0.9 }} onClick={onClose}
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: C.elevated }}>
                  <X size={14} style={{ color: C.textSecondary }} />
                </motion.button>
              </div>
            </div>
            <div className="flex gap-1.5 px-5 pb-3 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
              {types.map(t => (
                <motion.button key={t} whileTap={{ scale: 0.95 }} onClick={() => setFilter(t)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold capitalize whitespace-nowrap border"
                  style={{
                    backgroundColor: filter === t ? C.primary : C.elevated,
                    borderColor: filter === t ? C.primary : C.border,
                    color: filter === t ? "#fff" : C.textSecondary,
                  }}>
                  {t}
                </motion.button>
              ))}
            </div>
            <div className="flex-1 overflow-y-auto px-5 pb-6" style={{ scrollbarWidth: "none" }}>
              {filtered.length === 0 ? (
                <EmptyState icon={Bell} title="No Notifications" body="You're all caught up. New alerts will appear here." />
              ) : (
                <div className="flex flex-col gap-2">
                  {filtered.map(item => (
                    <motion.div key={item.id} layout initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
                      className="rounded-xl border p-3 flex items-start gap-3 relative"
                      style={{ backgroundColor: item.read ? C.elevated : C.elevated, borderColor: item.read ? C.border : item.color + "44" }}>
                      {!item.read && <div className="absolute top-3 right-3 w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />}
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                        style={{ backgroundColor: item.color + "22" }}>
                        <item.icon size={14} style={{ color: item.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold mb-0.5" style={{ color: C.textPrimary }}>{item.title}</div>
                        <div className="text-xs leading-relaxed" style={{ color: C.textSecondary }}>{item.body}</div>
                        <div className="text-[10px] mt-1" style={{ color: C.border.replace("#", "#a") }}>{item.time}</div>
                      </div>
                      <motion.button whileTap={{ scale: 0.9 }} onClick={() => remove(item.id)} className="shrink-0 mt-0.5">
                        <X size={12} style={{ color: C.textSecondary }} />
                      </motion.button>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── OVERLAY: Filter Sheet ────────────────────────────────────────────────────
const EXCHANGES_FILTER = ["Binance", "CoinDCX", "Kraken", "OKX", "Bybit", "Coinbase"];

function FilterSheet({ open, onClose, onApply }: { open: boolean; onClose: () => void; onApply: (f: Record<string, string>) => void }) {
  const [exch, setExch] = useState<string[]>([]);
  const [spread, setSpread] = useState("all");
  const [profit, setProfit] = useState("all");
  const [confidence, setConfidence] = useState("all");
  const [liquidity, setLiquidity] = useState("all");
  const [risk, setRisk] = useState("all");

  const toggleExch = (e: string) => setExch(prev => prev.includes(e) ? prev.filter(x => x !== e) : [...prev, e]);
  const reset = () => { setExch([]); setSpread("all"); setProfit("all"); setConfidence("all"); setLiquidity("all"); setRisk("all"); };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose} className="absolute inset-0 z-40" style={{ backgroundColor: "rgba(0,0,0,0.6)" }} />
          <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 35 }}
            className="absolute bottom-0 left-0 right-0 z-50 rounded-t-3xl overflow-hidden"
            style={{ backgroundColor: C.surface, border: `1px solid ${C.border}`, maxHeight: "86%" }}>
            <div className="flex items-center justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full" style={{ backgroundColor: C.border }} />
            </div>
            <div className="flex items-center justify-between px-5 py-3 border-b" style={{ borderColor: C.border }}>
              <div className="text-base font-bold" style={{ color: C.textPrimary }}>Filters</div>
              <div className="flex items-center gap-2">
                <motion.button whileTap={{ scale: 0.95 }} onClick={reset}
                  className="text-xs px-3 py-1.5 rounded-lg" style={{ color: C.textSecondary, backgroundColor: C.elevated }}>
                  Reset
                </motion.button>
                <motion.button whileTap={{ scale: 0.9 }} onClick={onClose}>
                  <X size={16} style={{ color: C.textSecondary }} />
                </motion.button>
              </div>
            </div>
            <div className="overflow-y-auto px-5 pb-24" style={{ scrollbarWidth: "none", maxHeight: "70vh" }}>
              {/* Exchange chips */}
              <div className="py-4 border-b" style={{ borderColor: C.border }}>
                <div className="text-xs font-semibold mb-3" style={{ color: C.textSecondary }}>Exchange</div>
                <div className="flex flex-wrap gap-2">
                  {EXCHANGES_FILTER.map(e => (
                    <motion.button key={e} whileTap={{ scale: 0.95 }} onClick={() => toggleExch(e)}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold border"
                      style={{
                        backgroundColor: exch.includes(e) ? C.primary + "22" : C.elevated,
                        borderColor: exch.includes(e) ? C.primary : C.border,
                        color: exch.includes(e) ? C.primary : C.textSecondary,
                      }}>
                      {e}
                    </motion.button>
                  ))}
                </div>
              </div>
              {/* Spread */}
              {[
                { label: "Spread %", val: spread, set: setSpread, opts: ["all", ">0.3%", ">0.5%", ">1%", ">2%"] },
                { label: "Min. Profit", val: profit, set: setProfit, opts: ["all", ">$25", ">$50", ">$100", ">$200"] },
                { label: "Confidence", val: confidence, set: setConfidence, opts: ["all", ">60%", ">70%", ">80%", ">90%"] },
                { label: "Liquidity", val: liquidity, set: setLiquidity, opts: ["all", "Low", "Medium", "High"] },
                { label: "Risk", val: risk, set: setRisk, opts: ["all", "Low", "Medium", "High"] },
              ].map(({ label, val, set, opts }) => (
                <div key={label} className="py-4 border-b" style={{ borderColor: C.border }}>
                  <div className="text-xs font-semibold mb-3" style={{ color: C.textSecondary }}>{label}</div>
                  <div className="flex flex-wrap gap-2">
                    {opts.map(o => (
                      <motion.button key={o} whileTap={{ scale: 0.95 }} onClick={() => set(o)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold border capitalize"
                        style={{
                          backgroundColor: val === o ? C.primary + "22" : C.elevated,
                          borderColor: val === o ? C.primary : C.border,
                          color: val === o ? C.primary : C.textSecondary,
                        }}>
                        {o === "all" ? "All" : o}
                      </motion.button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="absolute bottom-0 left-0 right-0 px-5 py-4 border-t" style={{ backgroundColor: C.surface, borderColor: C.border }}>
              <motion.button whileTap={{ scale: 0.97 }} onClick={() => { onApply({ spread, profit, confidence, liquidity, risk }); onClose(); }}
                className="w-full py-3.5 rounded-2xl text-sm font-bold"
                style={{ backgroundColor: C.primary, color: "#fff" }}>
                Apply Filters
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── Opportunity Card ─────────────────────────────────────────────────────────
function OpportunityCard({ opp, featured = false, onTap }: { opp: typeof opportunities[0]; featured?: boolean; onTap?: () => void }) {
  const riskColor = opp.risk === "Low" ? C.success : opp.risk === "Medium" ? C.warning : C.danger;
  const liqColor = opp.liquidity === "High" ? C.success : opp.liquidity === "Medium" ? C.warning : C.danger;
  const confColor = opp.confidence >= 85 ? C.success : opp.confidence >= 70 ? C.warning : C.danger;
  return (
    <motion.div whileTap={{ scale: 0.97 }} onClick={onTap}
      className="rounded-2xl border cursor-pointer relative overflow-hidden"
      style={{ backgroundColor: featured ? C.elevated : C.surface, borderColor: featured ? C.primary + "44" : C.border }}>
      {featured && <div className="absolute inset-0 pointer-events-none"
        style={{ background: `radial-gradient(ellipse at top right, ${C.primary}18 0%, transparent 60%)` }} />}
      <div className="p-4 relative">
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-base font-bold" style={{ color: C.textPrimary }}>{opp.symbol}</span>
              {opp.trending && <Badge label="Hot" color={C.warning} bg={C.warning + "22"} />}
            </div>
            <div className="flex items-center gap-1.5 text-xs" style={{ color: C.textSecondary }}>
              <span style={{ color: C.success }}>{opp.buyExchange}</span>
              <ArrowRightLeft size={10} style={{ color: C.textSecondary }} />
              <span style={{ color: C.danger }}>{opp.sellExchange}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xl font-bold font-mono" style={{ color: C.success }}>+{opp.spread}%</div>
            <div className="text-xs" style={{ color: C.textSecondary }}>spread</div>
          </div>
        </div>
        <div className="flex items-center justify-between mb-3">
          <div><div className="text-xs mb-1" style={{ color: C.textSecondary }}>Est. Profit</div>
            <div className="text-lg font-bold font-mono" style={{ color: C.textPrimary }}>${opp.profit.toFixed(2)}</div></div>
          <div className="w-36"><div className="text-xs mb-1" style={{ color: C.textSecondary }}>Confidence</div>
            <ConfidenceBar value={opp.confidence} color={confColor} /></div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <Badge label={`Liq: ${opp.liquidity}`} color={liqColor} bg={liqColor + "22"} />
            <Badge label={`Risk: ${opp.risk}`} color={riskColor} bg={riskColor + "22"} />
          </div>
          <div className="flex items-center gap-1 text-xs" style={{ color: C.textSecondary }}>
            <Clock size={10} /><span>{opp.detected}</span>
          </div>
        </div>
        {featured && (
          <motion.button whileTap={{ scale: 0.96 }}
            className="mt-3 w-full py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-1.5"
            style={{ backgroundColor: C.primary, color: "#fff" }}>
            <Zap size={14} />Paper Trade
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}

// ─── Opportunity Detail ───────────────────────────────────────────────────────
function OpportunityDetail({ opp, onBack }: { opp: typeof opportunities[0]; onBack: () => void }) {
  const [bookmarked, setBookmarked] = useState(false);
  const [shared, setShared] = useState(false);
  const riskColor = opp.risk === "Low" ? C.success : opp.risk === "Medium" ? C.warning : C.danger;
  const detailRows = [
    { label: "Buy Price", value: "$42,318.40", sub: `on ${opp.buyExchange}`, color: C.success },
    { label: "Sell Price", value: "$42,843.20", sub: `on ${opp.sellExchange}`, color: C.danger },
    { label: "Trading Fees", value: "-$24.80", sub: "both sides combined", color: C.warning },
    { label: "Network Fee", value: "-$8.60", sub: "estimated transfer", color: C.warning },
    { label: "Net Profit", value: `+$${opp.profit.toFixed(2)}`, sub: `${opp.spread}% spread`, color: C.success },
  ];
  const timeline = [
    { time: "12:04:02", label: "Spread detected", color: C.primary },
    { time: "12:04:05", label: "Confidence threshold met", color: C.success },
    { time: "12:04:08", label: "Alert triggered", color: C.warning },
    { time: "12:04:09", label: "You were notified", color: C.info },
  ];
  const miniData = [{ v: 0.4 }, { v: 0.6 }, { v: 0.9 }, { v: 0.7 }, { v: 1.1 }, { v: 1.24 }];

  return (
    <motion.div initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 40 }}
      transition={{ duration: 0.25 }} className="flex flex-col gap-5 pb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BackButton onBack={onBack} />
          <div><h2 className="text-lg font-bold" style={{ color: C.textPrimary }}>{opp.symbol}</h2>
            <p className="text-xs" style={{ color: C.textSecondary }}>Opportunity Detail</p></div>
        </div>
        <div className="flex items-center gap-2">
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShared(v => !v)}
            className="w-9 h-9 rounded-full flex items-center justify-center border"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Share2 size={14} style={{ color: shared ? C.primary : C.textSecondary }} />
          </motion.button>
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => setBookmarked(v => !v)}
            className="w-9 h-9 rounded-full flex items-center justify-center border"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Bookmark size={14} style={{ color: bookmarked ? C.warning : C.textSecondary }} fill={bookmarked ? C.warning : "none"} />
          </motion.button>
        </div>
      </div>
      {/* Hero */}
      <div className="rounded-2xl border p-5 relative overflow-hidden"
        style={{ backgroundColor: C.elevated, borderColor: C.primary + "44" }}>
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at top right, ${C.primary}20 0%, transparent 60%)` }} />
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="text-4xl font-bold font-mono" style={{ color: C.success }}>+{opp.spread}%</div>
            <div className="text-sm mt-1" style={{ color: C.textSecondary }}>Current Spread</div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold font-mono" style={{ color: C.textPrimary }}>${opp.profit.toFixed(2)}</div>
            <div className="text-sm mt-1" style={{ color: C.textSecondary }}>Est. Profit</div>
          </div>
        </div>
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 py-2 px-3 rounded-xl text-center" style={{ backgroundColor: C.success + "18" }}>
            <div className="text-xs mb-0.5" style={{ color: C.textSecondary }}>Buy at</div>
            <div className="text-sm font-semibold" style={{ color: C.success }}>{opp.buyExchange}</div>
          </div>
          <ArrowRightLeft size={16} style={{ color: C.textSecondary }} />
          <div className="flex-1 py-2 px-3 rounded-xl text-center" style={{ backgroundColor: C.danger + "18" }}>
            <div className="text-xs mb-0.5" style={{ color: C.textSecondary }}>Sell at</div>
            <div className="text-sm font-semibold" style={{ color: C.danger }}>{opp.sellExchange}</div>
          </div>
        </div>
        {/* Mini historical chart */}
        <div className="h-14">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={miniData}>
              <defs>
                <linearGradient id="mini-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.success} stopOpacity={0.4} />
                  <stop offset="95%" stopColor={C.success} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area key="mini-area" type="monotone" dataKey="v" stroke={C.success} strokeWidth={1.5} fill="url(#mini-grad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="text-xs mt-1" style={{ color: C.textSecondary }}>Spread trend (last 6 readings)</div>
      </div>
      {/* Confidence */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>Confidence Score</span>
          <span className="text-2xl font-bold font-mono" style={{ color: opp.confidence >= 85 ? C.success : C.warning }}>{opp.confidence}%</span>
        </div>
        <ConfidenceBar value={opp.confidence} color={opp.confidence >= 85 ? C.success : C.warning} />
        <p className="text-xs mt-2" style={{ color: C.textSecondary }}>Based on spread stability, liquidity depth, and volatility index</p>
      </GlassCard>
      {/* Price breakdown */}
      <div>
        <SectionLabel>Price Breakdown</SectionLabel>
        <GlassCard>
          {detailRows.map((row, i) => (
            <div key={row.label} className={`flex items-center justify-between p-3.5 ${i < detailRows.length - 1 ? "border-b" : ""}`}
              style={{ borderColor: C.border }}>
              <div><div className="text-sm" style={{ color: C.textPrimary }}>{row.label}</div>
                <div className="text-xs" style={{ color: C.textSecondary }}>{row.sub}</div></div>
              <span className="text-sm font-bold font-mono" style={{ color: row.color }}>{row.value}</span>
            </div>
          ))}
        </GlassCard>
      </div>
      {/* Market depth */}
      <GlassCard className="p-4">
        <div className="text-sm font-semibold mb-3" style={{ color: C.textPrimary }}>Market Depth</div>
        <div className="flex gap-3 mb-2">
          <div className="flex-1">
            <div className="text-xs mb-1" style={{ color: C.success }}>Bids</div>
            {[85, 70, 55, 40].map((w, i) => (
              <div key={i} className="flex items-center gap-2 mb-1">
                <div className="h-1.5 rounded-full" style={{ width: `${w}%`, backgroundColor: C.success + "66" }} />
                <span className="text-[10px] font-mono" style={{ color: C.textSecondary }}>${(120 - i * 30).toFixed(0)}K</span>
              </div>
            ))}
          </div>
          <div className="w-px" style={{ backgroundColor: C.border }} />
          <div className="flex-1">
            <div className="text-xs mb-1 text-right" style={{ color: C.danger }}>Asks</div>
            {[65, 80, 45, 30].map((w, i) => (
              <div key={i} className="flex items-center justify-end gap-2 mb-1">
                <span className="text-[10px] font-mono" style={{ color: C.textSecondary }}>${(90 + i * 20).toFixed(0)}K</span>
                <div className="h-1.5 rounded-full" style={{ width: `${w}%`, backgroundColor: C.danger + "66" }} />
              </div>
            ))}
          </div>
        </div>
      </GlassCard>
      {/* Timeline */}
      <div>
        <SectionLabel>Opportunity Timeline</SectionLabel>
        <GlassCard className="p-4">
          <div className="flex flex-col gap-3">
            {timeline.map((t, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: t.color }} />
                <span className="text-xs font-mono" style={{ color: C.textSecondary }}>{t.time}</span>
                <span className="text-xs" style={{ color: C.textPrimary }}>{t.label}</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
      {/* Risk & Liquidity */}
      <div className="grid grid-cols-2 gap-3">
        <GlassCard className="p-4">
          <div className="text-xs mb-1" style={{ color: C.textSecondary }}>Risk Level</div>
          <div className="text-base font-bold" style={{ color: riskColor }}>{opp.risk}</div>
        </GlassCard>
        <GlassCard className="p-4">
          <div className="text-xs mb-1" style={{ color: C.textSecondary }}>Liquidity</div>
          <div className="text-base font-bold" style={{ color: opp.liquidity === "High" ? C.success : opp.liquidity === "Medium" ? C.warning : C.danger }}>{opp.liquidity}</div>
        </GlassCard>
      </div>
      <motion.button whileTap={{ scale: 0.97 }}
        className="w-full py-4 rounded-2xl text-base font-bold flex items-center justify-center gap-2"
        style={{ backgroundColor: C.primary, color: "#fff" }}>
        <Zap size={18} />Start Paper Trade
      </motion.button>
    </motion.div>
  );
}

// ─── SCREEN: Dashboard ────────────────────────────────────────────────────────
function DashboardScreen({ onSelectOpp, onNotif, onSearch }: {
  onSelectOpp: (o: typeof opportunities[0]) => void; onNotif: () => void; onSearch: () => void;
}) {
  const [refreshing, setRefreshing] = useState(false);
  const unread = notificationsData.filter(n => !n.read).length;
  const totalProfit = opportunities.reduce((s, o) => s + o.profit, 0);

  return (
    <div className="flex flex-col gap-5 pb-8">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm" style={{ color: C.textSecondary }}>Good morning,</p>
          <h1 className="text-2xl font-bold" style={{ color: C.textPrimary }}>Alex</h1>
        </div>
        <div className="flex items-center gap-2">
          <motion.button whileTap={{ scale: 0.9 }} onClick={onSearch}
            className="w-9 h-9 rounded-full flex items-center justify-center border"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <Search size={15} style={{ color: C.textSecondary }} />
          </motion.button>
          <motion.button whileTap={{ scale: 0.9 }}
            onClick={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 1200); }}
            className="w-9 h-9 rounded-full flex items-center justify-center border"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <motion.div animate={{ rotate: refreshing ? 360 : 0 }} transition={{ duration: 0.8, ease: "linear" }}>
              <RefreshCw size={15} style={{ color: C.textSecondary }} />
            </motion.div>
          </motion.button>
          <div className="relative">
            <motion.button whileTap={{ scale: 0.9 }} onClick={onNotif}
              className="w-9 h-9 rounded-full flex items-center justify-center border"
              style={{ backgroundColor: C.elevated, borderColor: C.border }}>
              <Bell size={15} style={{ color: C.textSecondary }} />
            </motion.button>
            {unread > 0 && <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2"
              style={{ backgroundColor: C.danger, borderColor: C.bg }} />}
          </div>
        </div>
      </div>
      {/* Scanner status */}
      <GlassCard className="p-4 overflow-hidden relative">
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at bottom left, ${C.success}14 0%, transparent 55%)` }} />
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <motion.div animate={{ opacity: [1, 0.4, 1] }} transition={{ duration: 1.5, repeat: Infinity }}
              className="w-2 h-2 rounded-full" style={{ backgroundColor: C.success }} />
            <span className="text-sm font-semibold" style={{ color: C.success }}>Scanner Active</span>
          </div>
          <Badge label="Live" color={C.success} bg={C.success + "22"} />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <StatPill label="Exchanges" value="8" color={C.primary} />
          <StatPill label="Pairs" value="124" />
          <StatPill label="Opportunities" value={String(opportunities.length)} color={C.warning} />
        </div>
      </GlassCard>
      {/* Best opportunity */}
      <div>
        <SectionLabel>Today's Best Opportunity</SectionLabel>
        <OpportunityCard opp={opportunities[0]} featured onTap={() => onSelectOpp(opportunities[0])} />
      </div>
      {/* Market health */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>Market Health</span>
          <Badge label="Good" color={C.success} bg={C.success + "22"} />
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[{ label: "Volatility", value: "Low", color: C.success }, { label: "Volume", value: "High", color: C.success }, { label: "Liquidity", value: "Normal", color: C.warning }].map(m => (
            <div key={m.label} className="rounded-xl p-2.5 text-center" style={{ backgroundColor: C.elevated }}>
              <div className="text-[11px] mb-1" style={{ color: C.textSecondary }}>{m.label}</div>
              <div className="text-xs font-semibold" style={{ color: m.color }}>{m.value}</div>
            </div>
          ))}
        </div>
      </GlassCard>
      {/* Portfolio snapshot */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>Portfolio</span>
          <ChevronRight size={14} style={{ color: C.textSecondary }} />
        </div>
        <div className="text-2xl font-bold font-mono mb-1" style={{ color: C.textPrimary }}>$38,376.50</div>
        <div className="flex items-center gap-1.5">
          <ArrowUpRight size={14} style={{ color: C.success }} />
          <span className="text-sm font-semibold font-mono" style={{ color: C.success }}>+$921.40 (2.46%)</span>
          <span className="text-xs" style={{ color: C.textSecondary }}>today</span>
        </div>
      </GlassCard>
      {/* Recent opportunities */}
      <div>
        <SectionLabel>Recent Opportunities</SectionLabel>
        <div className="flex flex-col gap-3">
          {opportunities.slice(1, 4).map(opp => (
            <OpportunityCard key={opp.id} opp={opp} onTap={() => onSelectOpp(opp)} />
          ))}
        </div>
      </div>
      <GlassCard className="p-4">
        <SectionLabel>Est. Daily Profit</SectionLabel>
        <div className="text-3xl font-bold font-mono mb-1" style={{ color: C.success }}>${totalProfit.toFixed(2)}</div>
        <div className="text-xs" style={{ color: C.textSecondary }}>from {opportunities.length} active opportunities</div>
      </GlassCard>
    </div>
  );
}

// ─── SCREEN: Scanner ──────────────────────────────────────────────────────────
function ScannerScreen({ onSelectOpp, onFilter }: { onSelectOpp: (o: typeof opportunities[0]) => void; onFilter: () => void }) {
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState<"spread" | "profit" | "confidence">("spread");
  const [loading] = useState(false);

  const sorted = [...opportunities]
    .filter(o => o.symbol.toLowerCase().includes(query.toLowerCase()) || o.buyExchange.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => b[sortBy] - a[sortBy]);

  return (
    <div className="flex flex-col gap-4 pb-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold" style={{ color: C.textPrimary }}>Scanner</h2>
          <p className="text-xs" style={{ color: C.textSecondary }}>Live arbitrage feed</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <motion.div animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1.5, repeat: Infinity }}
              className="w-2 h-2 rounded-full" style={{ backgroundColor: C.success }} />
            <span className="text-xs font-semibold" style={{ color: C.success }}>Live</span>
          </div>
          <motion.button whileTap={{ scale: 0.9 }} onClick={onFilter}
            className="w-9 h-9 rounded-full flex items-center justify-center border"
            style={{ backgroundColor: C.elevated, borderColor: C.border }}>
            <SlidersHorizontal size={14} style={{ color: C.textSecondary }} />
          </motion.button>
        </div>
      </div>
      <div className="flex items-center gap-2 px-3 rounded-xl border h-11"
        style={{ backgroundColor: C.elevated, borderColor: C.border }}>
        <Search size={14} style={{ color: C.textSecondary }} />
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search symbol or exchange…"
          className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
        {query && <motion.button whileTap={{ scale: 0.9 }} onClick={() => setQuery("")}><X size={14} style={{ color: C.textSecondary }} /></motion.button>}
      </div>
      <div className="flex gap-2">
        {(["spread", "profit", "confidence"] as const).map(s => (
          <motion.button key={s} whileTap={{ scale: 0.95 }} onClick={() => setSortBy(s)}
            className="flex-1 py-2 rounded-xl text-xs font-semibold capitalize border"
            style={{ backgroundColor: sortBy === s ? C.primary : C.elevated, borderColor: sortBy === s ? C.primary : C.border, color: sortBy === s ? "#fff" : C.textSecondary }}>
            {s === "spread" ? "Spread %" : s === "profit" ? "Profit $" : "Confidence"}
          </motion.button>
        ))}
      </div>
      {loading ? <SkeletonList /> : sorted.length === 0 ? (
        <EmptyState icon={Radar} title="No Opportunities Found" body="Try adjusting your search or filters. The scanner is still running." ctaLabel="Clear Search" onCta={() => setQuery("")} />
      ) : (
        <div className="flex flex-col gap-3">
          {sorted.map((opp, i) => (
            <motion.div key={opp.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <OpportunityCard opp={opp} onTap={() => onSelectOpp(opp)} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── SCREEN: Portfolio ────────────────────────────────────────────────────────
function PortfolioScreen() {
  const [tab, setTab] = useState<PortfolioTab>("assets");
  const [tradingTab, setTradingTab] = useState<TradingTab>("open");
  const total = portfolioAssets.reduce((s, a) => s + a.value, 0);

  return (
    <div className="flex flex-col gap-4 pb-8">
      <div>
        <h2 className="text-xl font-bold" style={{ color: C.textPrimary }}>Portfolio</h2>
        <p className="text-xs" style={{ color: C.textSecondary }}>Across all connected exchanges</p>
      </div>
      {/* Total value */}
      <div className="rounded-2xl border p-5 relative overflow-hidden"
        style={{ backgroundColor: C.elevated, borderColor: C.primary + "44" }}>
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at top left, ${C.primary}18 0%, transparent 55%)` }} />
        <div className="text-xs mb-1" style={{ color: C.textSecondary }}>Total Value</div>
        <div className="text-4xl font-bold font-mono mb-2" style={{ color: C.textPrimary }}>
          ${total.toLocaleString("en-US", { minimumFractionDigits: 2 })}
        </div>
        <div className="flex items-center gap-1.5">
          <ArrowUpRight size={14} style={{ color: C.success }} />
          <span className="text-sm font-semibold font-mono" style={{ color: C.success }}>+$921.40</span>
          <span className="text-xs" style={{ color: C.textSecondary }}>today</span>
        </div>
      </div>
      {/* Sub-tabs */}
      <div className="flex gap-1 p-1 rounded-xl" style={{ backgroundColor: C.elevated }}>
        {(["assets", "trading", "history"] as const).map(t => (
          <motion.button key={t} whileTap={{ scale: 0.96 }} onClick={() => setTab(t)}
            className="flex-1 py-2 rounded-lg text-xs font-semibold capitalize"
            style={{ backgroundColor: tab === t ? C.surface : "transparent", color: tab === t ? C.textPrimary : C.textSecondary }}>
            {t === "trading" ? "Paper Trading" : t === "history" ? "History" : "Assets"}
          </motion.button>
        ))}
      </div>
      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
          {tab === "assets" && (
            <div className="flex flex-col gap-4">
              {/* Donut */}
              <GlassCard className="p-4">
                <SectionLabel>Asset Allocation</SectionLabel>
                <div className="flex items-center gap-4">
                  <PieChart width={110} height={110}>
                    <Pie data={portfolioAssets} dataKey="pct" cx={50} cy={50} innerRadius={30} outerRadius={50} strokeWidth={0}>
                      {portfolioAssets.map((a, i) => <Cell key={`cell-${i}`} fill={a.color} />)}
                    </Pie>
                  </PieChart>
                  <div className="flex flex-col gap-2 flex-1">
                    {portfolioAssets.map(a => (
                      <div key={a.symbol} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: a.color }} />
                          <span className="text-xs" style={{ color: C.textSecondary }}>{a.symbol}</span>
                        </div>
                        <span className="text-xs font-semibold font-mono" style={{ color: C.textPrimary }}>{a.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </GlassCard>
              {/* Assets */}
              <div>
                <SectionLabel>Assets</SectionLabel>
                <div className="flex flex-col gap-2">
                  {portfolioAssets.filter(a => a.symbol !== "–").map(a => (
                    <GlassCard key={a.symbol} className="p-4 flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold"
                        style={{ backgroundColor: a.color + "33", color: a.color }}>
                        {a.symbol.slice(0, 1)}
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-semibold" style={{ color: C.textPrimary }}>{a.name}</div>
                        <div className="text-xs" style={{ color: C.textSecondary }}>{a.symbol}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-bold font-mono" style={{ color: C.textPrimary }}>${a.value.toLocaleString()}</div>
                        <div className="flex items-center justify-end gap-0.5 text-xs font-semibold font-mono"
                          style={{ color: a.change >= 0 ? C.success : C.danger }}>
                          {a.change >= 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}{Math.abs(a.change)}%
                        </div>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </div>
              {/* Exchange balances */}
              <div>
                <SectionLabel>Exchange Balances</SectionLabel>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { name: "Binance", balance: "$18,420", ok: true }, { name: "Coinbase", balance: "$9,210", ok: true },
                    { name: "Kraken", balance: "$7,680", ok: true }, { name: "OKX", balance: "$3,066", ok: false },
                  ].map(ex => (
                    <GlassCard key={ex.name} className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold" style={{ color: C.textPrimary }}>{ex.name}</span>
                        <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: ex.ok ? C.success : C.warning }} />
                      </div>
                      <div className="text-base font-bold font-mono" style={{ color: C.textPrimary }}>{ex.balance}</div>
                    </GlassCard>
                  ))}
                </div>
              </div>
            </div>
          )}
          {tab === "trading" && (
            <div className="flex flex-col gap-4">
              {/* Virtual wallet */}
              <div className="rounded-2xl border p-4 relative overflow-hidden"
                style={{ backgroundColor: C.elevated, borderColor: C.success + "33" }}>
                <div className="absolute inset-0 pointer-events-none"
                  style={{ background: `radial-gradient(ellipse at top right, ${C.success}12 0%, transparent 55%)` }} />
                <div className="flex items-center justify-between mb-3">
                  <div className="text-xs font-semibold" style={{ color: C.textSecondary }}>Virtual Wallet</div>
                  <Badge label="Paper" color={C.primary} bg={C.primary + "22"} />
                </div>
                <div className="text-3xl font-bold font-mono mb-1" style={{ color: C.textPrimary }}>$1,842.00</div>
                <div className="flex items-center gap-1.5">
                  <ArrowUpRight size={13} style={{ color: C.success }} />
                  <span className="text-sm font-semibold font-mono" style={{ color: C.success }}>+$842.00 (+84.2%)</span>
                </div>
              </div>
              {/* Stats row */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "Win Rate", value: "82%", color: C.success },
                  { label: "Total Trades", value: "23", color: C.textPrimary },
                  { label: "Avg ROI", value: "18.4%", color: C.primary },
                ].map(s => (
                  <GlassCard key={s.label} className="p-3 text-center">
                    <div className="text-xs mb-1" style={{ color: C.textSecondary }}>{s.label}</div>
                    <div className="text-base font-bold font-mono" style={{ color: s.color }}>{s.value}</div>
                  </GlassCard>
                ))}
              </div>
              {/* Equity curve */}
              <GlassCard className="p-4">
                <div className="text-sm font-semibold mb-3" style={{ color: C.textPrimary }}>Equity Curve</div>
                <ResponsiveContainer width="100%" height={100}>
                  <AreaChart data={equityCurve}>
                    <defs>
                      <linearGradient id="eq-grad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={C.success} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={C.success} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis key="eq-xaxis" dataKey="day" tick={{ fill: C.textSecondary, fontSize: 9 }} axisLine={false} tickLine={false} />
                    <Tooltip key="eq-tooltip" contentStyle={{ backgroundColor: C.elevated, border: `1px solid ${C.border}`, borderRadius: 12, color: C.textPrimary, fontSize: 11 }} cursor={false} />
                    <Area key="eq-area" type="monotone" dataKey="value" stroke={C.success} strokeWidth={2} fill="url(#eq-grad)" dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </GlassCard>
              {/* Trade tabs */}
              <div className="flex gap-1 p-1 rounded-xl" style={{ backgroundColor: C.elevated }}>
                {(["open", "closed", "stats"] as const).map(t => (
                  <motion.button key={t} whileTap={{ scale: 0.96 }} onClick={() => setTradingTab(t)}
                    className="flex-1 py-1.5 rounded-lg text-xs font-semibold capitalize"
                    style={{ backgroundColor: tradingTab === t ? C.surface : "transparent", color: tradingTab === t ? C.textPrimary : C.textSecondary }}>
                    {t === "open" ? `Open (${openPositions.length})` : t === "closed" ? "Closed" : "Stats"}
                  </motion.button>
                ))}
              </div>
              <AnimatePresence mode="wait">
                <motion.div key={tradingTab} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
                  {tradingTab === "open" && (
                    openPositions.length === 0 ? (
                      <EmptyState icon={Zap} title="No Open Positions" body="Start a paper trade from any opportunity to practice risk-free." ctaLabel="Browse Opportunities" onCta={() => {}} />
                    ) : (
                      <div className="flex flex-col gap-3">
                        {openPositions.map(pos => (
                          <GlassCard key={pos.id} className="p-4">
                            <div className="flex items-center justify-between mb-2">
                              <div className="text-sm font-bold" style={{ color: C.textPrimary }}>{pos.symbol}</div>
                              <Badge label="Open" color={C.success} bg={C.success + "22"} />
                            </div>
                            <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color: C.textSecondary }}>
                              <span style={{ color: C.success }}>{pos.buyEx}</span>
                              <ArrowRightLeft size={9} />
                              <span style={{ color: C.danger }}>{pos.sellEx}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <div><div className="text-xs mb-0.5" style={{ color: C.textSecondary }}>Size</div>
                                <div className="text-sm font-mono" style={{ color: C.textPrimary }}>${pos.size}</div></div>
                              <div className="text-right"><div className="text-xs mb-0.5" style={{ color: C.textSecondary }}>Unrealized P&L</div>
                                <div className="text-sm font-bold font-mono" style={{ color: C.success }}>+${pos.currentProfit.toFixed(2)}</div></div>
                              <div className="text-right"><div className="text-xs mb-0.5" style={{ color: C.textSecondary }}>Opened</div>
                                <div className="text-xs" style={{ color: C.textSecondary }}>{pos.opened}</div></div>
                            </div>
                          </GlassCard>
                        ))}
                      </div>
                    )
                  )}
                  {tradingTab === "closed" && (
                    <div className="flex flex-col gap-3">
                      {closedPositions.map(pos => (
                        <GlassCard key={pos.id} className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="text-sm font-bold" style={{ color: C.textPrimary }}>{pos.symbol}</div>
                            <div className="text-sm font-bold font-mono" style={{ color: pos.profit >= 0 ? C.success : C.danger }}>
                              {pos.profit >= 0 ? "+" : ""}${pos.profit.toFixed(2)}
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 text-xs mb-2" style={{ color: C.textSecondary }}>
                            <span>{pos.buyEx}</span><ArrowRightLeft size={9} /><span>{pos.sellEx}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs" style={{ color: C.textSecondary }}>Size: ${pos.size}</span>
                            <span className="text-xs font-mono" style={{ color: pos.profit >= 0 ? C.success : C.danger }}>
                              {pos.pnlPct >= 0 ? "+" : ""}{pos.pnlPct}%
                            </span>
                            <span className="text-xs" style={{ color: C.textSecondary }}>{pos.closed}</span>
                          </div>
                        </GlassCard>
                      ))}
                    </div>
                  )}
                  {tradingTab === "stats" && (
                    <div className="flex flex-col gap-3">
                      {[
                        { label: "Total Trades", value: "23", color: C.textPrimary },
                        { label: "Winning Trades", value: "19", color: C.success },
                        { label: "Losing Trades", value: "4", color: C.danger },
                        { label: "Best Trade", value: "+$210.60", color: C.success },
                        { label: "Worst Trade", value: "-$18.40", color: C.danger },
                        { label: "Avg. ROI", value: "18.4%", color: C.primary },
                        { label: "Total Profit", value: "+$842.00", color: C.success },
                      ].map(s => (
                        <GlassCard key={s.label} className="px-4 py-3 flex items-center justify-between">
                          <span className="text-sm" style={{ color: C.textSecondary }}>{s.label}</span>
                          <span className="text-sm font-bold font-mono" style={{ color: s.color }}>{s.value}</span>
                        </GlassCard>
                      ))}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          )}
          {tab === "history" && (
            <div className="flex flex-col gap-3">
              <SectionLabel>Transaction History</SectionLabel>
              {txHistory.map(tx => (
                <GlassCard key={tx.id} className="p-4 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: tx.color + "22" }}>
                    {tx.type === "deposit" ? <ArrowUpRight size={15} style={{ color: tx.color }} /> :
                      tx.type === "withdrawal" ? <ArrowDownRight size={15} style={{ color: tx.color }} /> :
                        <ArrowRightLeft size={15} style={{ color: tx.color }} />}
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold capitalize" style={{ color: C.textPrimary }}>{tx.type}</div>
                    <div className="text-xs" style={{ color: C.textSecondary }}>{tx.exchange} · {tx.date}</div>
                  </div>
                  <div className="text-sm font-bold font-mono" style={{ color: tx.color }}>{tx.amount} {tx.asset}</div>
                </GlassCard>
              ))}
              {txHistory.length === 0 && <EmptyState icon={History} title="No Transactions" body="Your transaction history will appear here." />}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ─── SCREEN: Insights ─────────────────────────────────────────────────────────
function InsightsScreen() {
  const [period, setPeriod] = useState<"Day" | "Week" | "Month">("Week");
  return (
    <div className="flex flex-col gap-5 pb-8">
      <div>
        <h2 className="text-xl font-bold" style={{ color: C.textPrimary }}>Insights</h2>
        <p className="text-xs" style={{ color: C.textSecondary }}>Intelligent market analysis</p>
      </div>
      <div className="flex gap-2">
        {(["Day", "Week", "Month"] as const).map(p => (
          <motion.button key={p} whileTap={{ scale: 0.95 }} onClick={() => setPeriod(p)}
            className="flex-1 py-2 rounded-xl text-xs font-semibold border"
            style={{ backgroundColor: period === p ? C.primary : C.elevated, borderColor: period === p ? C.primary : C.border, color: period === p ? "#fff" : C.textSecondary }}>
            {p}
          </motion.button>
        ))}
      </div>
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>Profit Trend</span>
          <span className="text-base font-bold font-mono" style={{ color: C.success }}>+$2,222</span>
        </div>
        <ResponsiveContainer width="100%" height={120}>
          <AreaChart data={performanceData}>
            <defs>
              <linearGradient id="pf-profitGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={C.success} stopOpacity={0.3} />
                <stop offset="95%" stopColor={C.success} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis key="pf-xaxis" dataKey="day" tick={{ fill: C.textSecondary, fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip key="pf-tooltip" contentStyle={{ backgroundColor: C.elevated, border: `1px solid ${C.border}`, borderRadius: 12, color: C.textPrimary, fontSize: 12 }} cursor={false} />
            <Area key="pf-area" type="monotone" dataKey="profit" stroke={C.success} strokeWidth={2} fill="url(#pf-profitGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </GlassCard>
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>Spread History (24h)</span>
        </div>
        <div className="flex items-center gap-4 mb-3 text-xs" style={{ color: C.textSecondary }}>
          <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 rounded" style={{ backgroundColor: C.primary }} />BTC</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 rounded" style={{ backgroundColor: C.success }} />ETH</div>
        </div>
        <ResponsiveContainer width="100%" height={100}>
          <AreaChart data={spreadHistory}>
            <defs>
              <linearGradient id="pf-btcGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={C.primary} stopOpacity={0.25} />
                <stop offset="95%" stopColor={C.primary} stopOpacity={0} />
              </linearGradient>
              <linearGradient id="pf-ethGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={C.success} stopOpacity={0.2} />
                <stop offset="95%" stopColor={C.success} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis key="spread-xaxis" dataKey="time" tick={{ fill: C.textSecondary, fontSize: 9 }} axisLine={false} tickLine={false} />
            <Tooltip key="spread-tooltip" contentStyle={{ backgroundColor: C.elevated, border: `1px solid ${C.border}`, borderRadius: 12, color: C.textPrimary, fontSize: 11 }} cursor={false} />
            <Area key="spread-btc" type="monotone" dataKey="btc" stroke={C.primary} strokeWidth={2} fill="url(#pf-btcGrad)" dot={false} />
            <Area key="spread-eth" type="monotone" dataKey="eth" stroke={C.success} strokeWidth={2} fill="url(#pf-ethGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </GlassCard>
      {/* Exchange comparison bar */}
      <GlassCard className="p-4">
        <div className="text-sm font-semibold mb-3" style={{ color: C.textPrimary }}>Exchange Performance</div>
        <ResponsiveContainer width="100%" height={100}>
          <BarChart data={[
            { name: "CoinDCX", avg: 1.1 }, { name: "Binance", avg: 0.9 }, { name: "Kraken", avg: 0.7 },
            { name: "OKX", avg: 0.6 }, { name: "Bybit", avg: 0.5 },
          ]}>
            <XAxis key="bar-xaxis" dataKey="name" tick={{ fill: C.textSecondary, fontSize: 9 }} axisLine={false} tickLine={false} />
            <Tooltip key="bar-tooltip" contentStyle={{ backgroundColor: C.elevated, border: `1px solid ${C.border}`, borderRadius: 12, color: C.textPrimary, fontSize: 11 }} cursor={false} />
            <Bar key="bar-avg" dataKey="avg" fill={C.primary} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="text-xs mt-1" style={{ color: C.textSecondary }}>Average spread % by exchange</div>
      </GlassCard>
      <div>
        <SectionLabel>Smart Insights</SectionLabel>
        <div className="flex flex-col gap-3">
          {insights.map((ins, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
              <GlassCard className="p-4 flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: ins.color + "22" }}>
                  <ins.icon size={15} style={{ color: ins.color }} />
                </div>
                <div className="flex-1">
                  <Badge label={ins.tag} color={ins.color} bg={ins.color + "22"} />
                  <p className="text-xs mt-1.5 leading-relaxed" style={{ color: C.textSecondary }}>{ins.label}</p>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
      <GlassCard className="p-4">
        <SectionLabel>Scanner Statistics</SectionLabel>
        <div className="grid grid-cols-2 gap-3">
          {[{ label: "Opportunities", value: "847", color: C.primary }, { label: "Paper Trades", value: "23", color: C.success }, { label: "Avg. Spread", value: "0.74%", color: C.warning }, { label: "Win Rate", value: "82%", color: C.success }].map(s => (
            <div key={s.label} className="rounded-xl p-3" style={{ backgroundColor: C.elevated }}>
              <div className="text-xs mb-1" style={{ color: C.textSecondary }}>{s.label}</div>
              <div className="text-lg font-bold font-mono" style={{ color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}

// ─── SCREEN: Profile ──────────────────────────────────────────────────────────
function ProfileScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex flex-col gap-5 pb-8">
      <div className="flex items-center gap-3">
        <BackButton onBack={onBack} />
        <div className="text-lg font-bold" style={{ color: C.textPrimary }}>Profile</div>
      </div>
      <div className="flex flex-col items-center gap-4 py-4">
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-2xl font-bold"
          style={{ background: `linear-gradient(135deg, ${C.primary}, ${C.info})`, color: "#fff" }}>AJ</div>
        <div className="text-center">
          <div className="text-xl font-bold" style={{ color: C.textPrimary }}>Alex Johnson</div>
          <div className="text-sm" style={{ color: C.textSecondary }}>alex@profitflow.io</div>
          <Badge label="Pro Plan" color={C.primary} bg={C.primary + "22"} />
        </div>
      </div>
      <GlassCard className="p-4">
        <SectionLabel>Account Details</SectionLabel>
        {[
          { label: "Full Name", value: "Alex Johnson" },
          { label: "Email", value: "alex@profitflow.io" },
          { label: "Member Since", value: "January 2024" },
          { label: "Subscription", value: "Pro Plan" },
        ].map((row, i, arr) => (
          <div key={row.label} className={`flex items-center justify-between py-3 ${i < arr.length - 1 ? "border-b" : ""}`}
            style={{ borderColor: C.border }}>
            <span className="text-sm" style={{ color: C.textSecondary }}>{row.label}</span>
            <span className="text-sm font-semibold" style={{ color: C.textPrimary }}>{row.value}</span>
          </div>
        ))}
      </GlassCard>
      <GlassCard className="p-4">
        <SectionLabel>Status</SectionLabel>
        {[
          { label: "Connected Exchanges", value: "2 Active", color: C.success },
          { label: "Scanner Status", value: "Running", color: C.success },
          { label: "Security", value: "2FA Enabled", color: C.success },
          { label: "API Keys", value: "2 Active", color: C.primary },
        ].map((row, i, arr) => (
          <div key={row.label} className={`flex items-center justify-between py-3 ${i < arr.length - 1 ? "border-b" : ""}`}
            style={{ borderColor: C.border }}>
            <span className="text-sm" style={{ color: C.textSecondary }}>{row.label}</span>
            <span className="text-sm font-semibold" style={{ color: row.color }}>{row.value}</span>
          </div>
        ))}
      </GlassCard>
      <motion.button whileTap={{ scale: 0.97 }}
        className="w-full py-3.5 rounded-2xl text-sm font-semibold border"
        style={{ backgroundColor: "transparent", borderColor: C.border, color: C.textSecondary }}>
        Edit Profile
      </motion.button>
    </div>
  );
}

// ─── SCREEN: Exchange Management ──────────────────────────────────────────────
function ExchangeManagementScreen({ onBack, onConnect }: { onBack: () => void; onConnect: (id: string) => void }) {
  return (
    <div className="flex flex-col gap-5 pb-8">
      <div className="flex items-center gap-3">
        <BackButton onBack={onBack} />
        <div className="text-lg font-bold" style={{ color: C.textPrimary }}>Exchanges</div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {exchangeList.map(ex => (
          <motion.button key={ex.id} whileTap={{ scale: 0.96 }}
            onClick={() => !ex.connected && !ex.soon && onConnect(ex.id)}
            className="rounded-2xl border p-4 flex flex-col gap-2 text-left relative"
            style={{
              backgroundColor: ex.connected ? C.primary + "18" : C.elevated,
              borderColor: ex.connected ? C.primary + "44" : C.border,
              opacity: ex.soon ? 0.5 : 1,
            }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-base font-bold"
              style={{ backgroundColor: ex.color + "22", color: ex.color }}>{ex.logo}</div>
            <div className="text-sm font-semibold" style={{ color: C.textPrimary }}>{ex.name}</div>
            <div className="text-xs" style={{ color: ex.connected ? C.success : ex.soon ? C.textSecondary : C.primary }}>
              {ex.connected ? "● Connected" : ex.soon ? "Coming Soon" : "Tap to connect"}
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

// ─── SCREEN: Settings ─────────────────────────────────────────────────────────
function SettingsScreen({ onProfile, onExchanges }: { onProfile: () => void; onExchanges: () => void }) {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [biometric, setBiometric] = useState(false);

  const Toggle = ({ val, onToggle }: { val: boolean; onToggle: () => void }) => (
    <motion.button onClick={onToggle}
      className="w-10 h-6 rounded-full relative shrink-0" style={{ backgroundColor: val ? C.primary : C.border }}>
      <motion.div animate={{ x: val ? 16 : 2 }} transition={{ type: "spring", stiffness: 400, damping: 30 }}
        className="absolute top-1 w-4 h-4 rounded-full bg-white" />
    </motion.button>
  );

  const sections = [
    {
      title: "Account",
      items: [
        { icon: User, label: "Profile", action: onProfile, value: "Alex Johnson" },
        { icon: Globe, label: "Exchange Management", action: onExchanges, value: "2 connected" },
        { icon: Key, label: "API Keys", value: "2 active" },
        { icon: Award, label: "Subscription", value: "Pro Plan" },
      ],
    },
    {
      title: "Preferences",
      items: [
        { icon: Bell, label: "Notifications", toggle: notifications, onToggle: () => setNotifications(v => !v) },
        { icon: Moon, label: "Dark Mode", toggle: darkMode, onToggle: () => setDarkMode(v => !v) },
        { icon: Fingerprint, label: "Biometric Auth", toggle: biometric, onToggle: () => setBiometric(v => !v) },
        { icon: Languages, label: "Language", value: "English" },
        { icon: Sun, label: "Theme", value: "Dark" },
      ],
    },
    {
      title: "Scanner",
      items: [
        { icon: Radar, label: "Scanner Rules", value: "Configure" },
        { icon: Filter, label: "Min. Spread", value: "0.3%" },
        { icon: Target, label: "Min. Confidence", value: "65%" },
        { icon: Cpu, label: "Scan Interval", value: "5s" },
      ],
    },
    {
      title: "Security & Privacy",
      items: [
        { icon: Shield, label: "Two-Factor Auth", value: "Enabled" },
        { icon: Lock, label: "Change Password" },
        { icon: FileText, label: "Privacy Policy" },
        { icon: Info, label: "Terms of Service" },
      ],
    },
    {
      title: "Support",
      items: [
        { icon: HelpCircle, label: "Help Center" },
        { icon: Activity, label: "App Version", value: "v2.4.1" },
        { icon: LogOut, label: "Sign Out", danger: true },
      ],
    },
  ];

  return (
    <div className="flex flex-col gap-5 pb-8">
      <GlassCard className="p-4 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold"
          style={{ background: `linear-gradient(135deg, ${C.primary}, ${C.info})`, color: "#fff" }}>AJ</div>
        <div>
          <div className="text-base font-bold" style={{ color: C.textPrimary }}>Alex Johnson</div>
          <div className="text-xs" style={{ color: C.textSecondary }}>alex@profitflow.io</div>
          <div className="mt-1"><Badge label="Pro Plan" color={C.primary} bg={C.primary + "22"} /></div>
        </div>
      </GlassCard>
      {sections.map(section => (
        <div key={section.title}>
          <SectionLabel>{section.title}</SectionLabel>
          <GlassCard>
            {section.items.map((item, i) => (
              <motion.div key={item.label} whileTap={{ scale: 0.99 }}
                onClick={(item as any).action}
                className={`flex items-center gap-3 p-4 cursor-pointer ${i < section.items.length - 1 ? "border-b" : ""}`}
                style={{ borderColor: C.border }}>
                <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: (item as any).danger ? C.danger + "22" : C.elevated }}>
                  <item.icon size={15} style={{ color: (item as any).danger ? C.danger : C.textSecondary }} />
                </div>
                <span className="flex-1 text-sm" style={{ color: (item as any).danger ? C.danger : C.textPrimary }}>{item.label}</span>
                {"toggle" in item
                  ? <Toggle val={item.toggle as boolean} onToggle={item.onToggle as () => void} />
                  : <span className="text-xs" style={{ color: C.textSecondary }}>{(item as any).value}</span>}
              </motion.div>
            ))}
          </GlassCard>
        </div>
      ))}
    </div>
  );
}

// ─── OVERLAY: Global Search ───────────────────────────────────────────────────
function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const results = q.length > 1 ? opportunities.filter(o =>
    o.symbol.toLowerCase().includes(q.toLowerCase()) || o.buyExchange.toLowerCase().includes(q.toLowerCase())
  ) : [];

  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="absolute inset-0 z-50 flex flex-col" style={{ backgroundColor: C.bg }}>
          <div className="flex items-center gap-3 px-5 pt-12 pb-4">
            <div className="flex-1 flex items-center gap-2 px-3 rounded-xl border h-11"
              style={{ backgroundColor: C.elevated, borderColor: C.border }}>
              <Search size={14} style={{ color: C.textSecondary }} />
              <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search opportunities, coins…"
                className="flex-1 bg-transparent text-sm outline-none" style={{ color: C.textPrimary }} />
            </div>
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => { setQ(""); onClose(); }}
              className="text-sm" style={{ color: C.primary }}>Cancel</motion.button>
          </div>
          <div className="flex-1 px-5 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
            {q.length === 0 && (
              <div>
                <SectionLabel>Recent Searches</SectionLabel>
                {["BTC/USDT", "Binance", "ETH arbitrage"].map(s => (
                  <motion.button key={s} whileTap={{ scale: 0.98 }} onClick={() => setQ(s)}
                    className="flex items-center gap-3 w-full py-3 border-b" style={{ borderColor: C.border }}>
                    <Clock size={13} style={{ color: C.textSecondary }} />
                    <span className="text-sm" style={{ color: C.textPrimary }}>{s}</span>
                  </motion.button>
                ))}
              </div>
            )}
            {q.length > 1 && results.length === 0 && (
              <EmptyState icon={Search} title="No Results" body={`No opportunities match "${q}"`} />
            )}
            {results.length > 0 && (
              <div className="flex flex-col gap-3">
                <SectionLabel>Opportunities</SectionLabel>
                {results.map(opp => (
                  <OpportunityCard key={opp.id} opp={opp} onTap={onClose} />
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────
const navItems = [
  { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { id: "scanner", icon: Radar, label: "Scanner" },
  { id: "portfolio", icon: Briefcase, label: "Portfolio" },
  { id: "insights", icon: BarChart3, label: "Insights" },
  { id: "settings", icon: Settings, label: "Settings" },
];

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [appMode, setAppMode] = useState<"auth" | "main">("auth");
  const [authStep, setAuthStep] = useState<AuthStep>("splash");
  const [mainTab, setMainTab] = useState<MainTab>("dashboard");
  const [selectedOpp, setSelectedOpp] = useState<typeof opportunities[0] | null>(null);
  const [showNotif, setShowNotif] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  const [settingsSub, setSettingsSub] = useState<SettingsSub>(null);
  const [connectingExchange, setConnectingExchange] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const goToMain = () => { setAppMode("main"); setMainTab("dashboard"); };

  const handleTabChange = (id: string) => {
    setMainTab(id as MainTab);
    setSelectedOpp(null);
    setSettingsSub(null);
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSelectOpp = (opp: typeof opportunities[0]) => {
    setSelectedOpp(opp);
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  const renderAuthScreen = () => {
    switch (authStep) {
      case "splash": return <SplashScreen onDone={() => setAuthStep("welcome")} />;
      case "welcome": return <WelcomeScreen onLogin={() => setAuthStep("login")} onRegister={() => setAuthStep("register")} />;
      case "login": return <LoginScreen onSuccess={goToMain} onRegister={() => setAuthStep("register")} onForgot={() => setAuthStep("forgot")} onBack={() => setAuthStep("welcome")} />;
      case "register": return <RegisterScreen onNext={() => setAuthStep("verify")} onLogin={() => setAuthStep("login")} onBack={() => setAuthStep("welcome")} />;
      case "forgot": return <ForgotPasswordScreen onBack={() => setAuthStep("login")} onSent={() => setAuthStep("verify")} />;
      case "verify": return <VerifyScreen onVerified={() => setAuthStep("success")} onBack={() => setAuthStep("login")} />;
      case "success": return <AuthSuccessScreen onContinue={() => setAuthStep("exchange-setup")} />;
      case "exchange-setup": return <ExchangeSetupScreen onDone={goToMain} />;
      default: return null;
    }
  };

  const renderMainScreen = () => {
    if (selectedOpp) return <OpportunityDetail opp={selectedOpp} onBack={() => setSelectedOpp(null)} />;
    if (mainTab === "settings") {
      if (settingsSub === "profile") return <ProfileScreen onBack={() => setSettingsSub(null)} />;
      if (settingsSub === "exchanges") return <ExchangeManagementScreen onBack={() => setSettingsSub(null)} onConnect={id => { setConnectingExchange(id); setSettingsSub("exchange-connect"); }} />;
      if (settingsSub === "exchange-connect") return <ExchangeSetupScreen onDone={() => setSettingsSub(null)} />;
      return <SettingsScreen onProfile={() => setSettingsSub("profile")} onExchanges={() => setSettingsSub("exchanges")} />;
    }
    switch (mainTab) {
      case "dashboard": return <DashboardScreen onSelectOpp={handleSelectOpp} onNotif={() => setShowNotif(true)} onSearch={() => setShowSearch(true)} />;
      case "scanner": return <ScannerScreen onSelectOpp={handleSelectOpp} onFilter={() => setShowFilter(true)} />;
      case "portfolio": return <PortfolioScreen />;
      case "insights": return <InsightsScreen />;
      default: return null;
    }
  };

  return (
    <div className="size-full flex items-center justify-center"
      style={{ background: `radial-gradient(ellipse at 50% 0%, #1a2a4a 0%, #050810 60%)`, fontFamily: "'Inter', sans-serif" }}>
      <div className="relative flex flex-col overflow-hidden"
        style={{
          width: 390, height: "min(844px, 100vh)",
          backgroundColor: C.bg,
          borderRadius: "min(44px, 4vw)",
          boxShadow: "0 32px 96px rgba(0,0,0,0.8), 0 0 0 1px #273246",
        }}>
        {/* Status bar */}
        <div className="flex items-center justify-between px-6 pt-3 pb-1 shrink-0" style={{ color: C.textPrimary }}>
          <span className="text-xs font-semibold">9:41</span>
          <div className="flex items-center gap-1.5">
            <Wifi size={12} />
            <div className="flex gap-0.5 items-end">
              {[3, 5, 7, 9].map(h => <div key={h} className="w-1 rounded-sm" style={{ height: h, backgroundColor: C.textPrimary }} />)}
            </div>
          </div>
        </div>

        {/* Auth flow */}
        {appMode === "auth" && (
          <AnimatePresence mode="wait">
            <motion.div key={authStep} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.22 }} className="flex-1 overflow-hidden">
              {renderAuthScreen()}
            </motion.div>
          </AnimatePresence>
        )}

        {/* Main app */}
        {appMode === "main" && (
          <>
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 pt-3" style={{ scrollbarWidth: "none" }}>
              <AnimatePresence mode="wait">
                <motion.div key={mainTab + (selectedOpp ? "-detail" : "") + (settingsSub ?? "")}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }}>
                  {renderMainScreen()}
                </motion.div>
              </AnimatePresence>
            </div>
            {/* Bottom nav */}
            <div className="shrink-0 px-3 pt-2 pb-5 border-t"
              style={{ backgroundColor: C.surface + "ee", borderColor: C.border, backdropFilter: "blur(12px)" }}>
              <div className="flex items-center justify-around">
                {navItems.map(item => {
                  const active = mainTab === item.id && !selectedOpp && !settingsSub;
                  return (
                    <motion.button key={item.id} whileTap={{ scale: 0.88 }} onClick={() => handleTabChange(item.id)}
                      className="flex flex-col items-center gap-1 py-1 px-3 rounded-xl relative">
                      {active && (
                        <motion.div layoutId="navIndicator" className="absolute inset-0 rounded-xl"
                          style={{ backgroundColor: C.primary + "22" }}
                          transition={{ type: "spring", stiffness: 350, damping: 35 }} />
                      )}
                      <item.icon size={20} style={{ color: active ? C.primary : C.textSecondary }} />
                      <span className="text-[9px] font-semibold" style={{ color: active ? C.primary : C.textSecondary }}>{item.label}</span>
                    </motion.button>
                  );
                })}
              </div>
            </div>
            {/* Overlays */}
            <NotificationPanel open={showNotif} onClose={() => setShowNotif(false)} />
            <FilterSheet open={showFilter} onClose={() => setShowFilter(false)} onApply={() => {}} />
            <SearchOverlay open={showSearch} onClose={() => setShowSearch(false)} />
          </>
        )}
      </div>
    </div>
  );
}
