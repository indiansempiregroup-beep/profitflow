
  # Review Attachment

  This is a code bundle for Review Attachment. The original project is available at https://www.figma.com/design/GLpTUPSua5HqWPp6MheZ7P/Review-Attachment.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  